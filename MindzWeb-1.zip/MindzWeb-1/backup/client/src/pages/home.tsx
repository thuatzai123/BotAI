export default function Home() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center">
      <h1 
        className="text-4xl md:text-5xl lg:text-6xl font-normal tracking-tight select-none text-gray-900" 
        data-testid="text-mindz"
      >
        mindz
      </h1>
    </div>
  );
}
