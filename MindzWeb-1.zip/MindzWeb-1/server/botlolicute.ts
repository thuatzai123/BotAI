import mineflayer, { Bot } from 'mineflayer'
import { pathfinder, Movements } from 'mineflayer-pathfinder'
import * as net from 'net'

// Import goals using createRequire for CommonJS module
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const { goals } = require('mineflayer-pathfinder')
// import autoEat from 'mineflayer-auto-eat'
import { plugin as pvp } from 'mineflayer-pvp'
import { plugin as collectBlock } from 'mineflayer-collectblock'
import { Vec3 } from 'vec3'

// Import Facebook Messenger Bot
// import { botMessenger } from './botmessenger.js' // Disabled for now

const geminiApiKey = process.env.GEMINI_API_KEY // Google Gemini API key

// Bot configuration
const BOT_CONFIG = {
  host: process.env.MINECRAFT_SERVER_HOST || 'thuatzai123.aternos.me',
  port: parseInt(process.env.MINECRAFT_SERVER_PORT || '38893'),
  username: process.env.MINECRAFT_BOT_USERNAME || 'botlolicute',
  version: process.env.MINECRAFT_VERSION || '1.19.4',
  auth: 'offline' as const
}

// Biến trạng thái global
let bot: Bot
let targetPlayer: any = null
let followInterval: NodeJS.Timeout | null = null
let protectInterval: NodeJS.Timeout | null = null
let autoFarmActive = false
let isFollowing = false
let isProtecting = false
let autoChestHuntActive = false
let lootedChests: Set<string> = new Set() // Ghi nhớ rương đã loot
let isEating = false // Track trạng thái đang ăn
let autoFishingActive = false // Track trạng thái câu cá
let autoItemCollectionDisabled = false // Tạm dừng nhặt đồ khi câu cá
let autoEquipDisabled = false // Tạm dừng tự động trang bị khi câu cá
let lastPlayerCommand = Date.now() // Track lần cuối player ra lệnh
let lastEatTime = 0 // Track lần cuối ăn để tránh spam
let bobberThrowCount = 0 // Đếm số lần âm thanh fishing_bobber.throw
let reconnectAttempts = 0
const MAX_RECONNECT_ATTEMPTS = 5
// Auto bow mode removed

// Auto mining variables
let autoMiningActive = false // Track trạng thái auto mining
let targetOreType = '' // Loại quặng đang đào
let miningInterval: NodeJS.Timeout | null = null
let currentMiningTarget: any = null

// Auto chest hunting variables
let autoChestActive = false // Track trạng thái auto tìm rương
let chestInterval: NodeJS.Timeout | null = null
let currentChestTarget: any = null
let chestStats = {
  chestsFound: 0,
  startTime: 0,
  explorationCount: 0
}

// Biến cho respawn handling
let lastMode = 'idle' // Track chế độ trước khi chết
let lastPosition: any = null // Track vị trí trước khi chết
let lastTargetPlayerName = '' // Track tên player đang theo/bảo vệ
let hasTpPermission: boolean | null = null // Track quyền /tp
let tpFailCount = 0 // Đếm số lần /tp thất bại
let lastAttackTime = 0 // Track lần cuối tấn công để cooldown

// Auto mining variables removed

async function testServerConnection() {
  return new Promise((resolve) => {
    const socket = new net.Socket()

    socket.setTimeout(5000) // 5 second timeout

    socket.on('connect', () => {
      socket.destroy()
      resolve(true)
    })

    socket.on('timeout', () => {
      socket.destroy()
      resolve(false)
    })

    socket.on('error', () => {
      resolve(false)
    })

    socket.connect(BOT_CONFIG.port, BOT_CONFIG.host)
  })
}

async function createBot() {
  console.log(`🚀 Đang tạo bot mới... (Thử lần ${reconnectAttempts + 1}/${MAX_RECONNECT_ATTEMPTS})`)
  console.log(`📡 Kết nối tới: ${BOT_CONFIG.host}:${BOT_CONFIG.port}`)

  if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
    console.log('❌ Đã vượt quá số lần thử kết nối tối đa. Dừng bot.')
    console.log('💡 Gợi ý: Kiểm tra xem server Minecraft có đang online không:')
    console.log(`   - Truy cập https://${BOT_CONFIG.host} để kiểm tra status`)
    console.log('   - Hoặc thay đổi MINECRAFT_SERVER_HOST trong file .env')
    return
  }

  // Test server connectivity first
  console.log('🔍 Kiểm tra kết nối server...')
  const serverOnline = await testServerConnection()

  if (!serverOnline) {
    console.log('❌ Server không phản hồi. Server có thể đang offline.')
    console.log('💡 Gợi ý:')
    console.log('   1. Kiểm tra server Aternos có đang chạy không')
    console.log('   2. Thử kết nối bằng Minecraft client trước')
    console.log('   3. Kiểm tra địa chỉ server và port có đúng không')
    console.log('⏳ Sẽ thử lại sau...')

    // Still attempt connection but with warning
  } else {
    console.log('✅ Server phản hồi, đang kết nối bot...')
  }

  bot = mineflayer.createBot({
    host: BOT_CONFIG.host,
    port: BOT_CONFIG.port,
    username: BOT_CONFIG.username,
    version: BOT_CONFIG.version,
    auth: BOT_CONFIG.auth,
    keepAlive: true,
    checkTimeoutInterval: 60000, // Check connection mỗi 60s
    hideErrors: false
  })

  // Tăng MaxListeners để tránh warning
  bot.setMaxListeners(100)

  // Load plugins with error handling
  try {
    bot.loadPlugin(pathfinder)
    // bot.loadPlugin(autoEat) // Disabled due to import issues
    bot.loadPlugin(pvp)
    bot.loadPlugin(collectBlock)
    console.log('✅ Plugins loaded successfully')
  } catch (pluginError) {
    console.log('⚠️ Warning loading plugins:', pluginError)
  }

  // Connection events
  bot.on('login', () => {
    console.log('🔑 Bot đang đăng nhập...')
  })

  bot.on('spawn', () => {
    console.log('🎉 Bot đã spawn thành công!')
    reconnectAttempts = 0 // Reset on successful connection

    // Thông báo qua Facebook Messenger
    // botMessenger.notifyOwner('bot_respawned', 'Bot đã hồi sinh thành công')

    // Đợi 2 giây cho bot ổn định trước khi setup
    setTimeout(() => {
      try {
        const defaultMove = new Movements(bot)
        bot.pathfinder.setMovements(defaultMove)

        // Start các chức năng với delay
        setTimeout(() => startStatusUpdates(), 1000)
        setTimeout(() => autoEatSetup(), 2000) 
        setTimeout(() => collectNearbyItems(), 3000)

        // Xử lý respawn sau khi bot đã ổn định
        setTimeout(() => handleRespawn(), 5000)

        console.log('✅ Bot setup hoàn tất và ổn định')
      } catch (error) {
        console.log('⚠️ Lỗi setup bot sau spawn:', error)
      }
    }, 2000)
  })

  bot.on('death', () => {
    console.log('💀 Bot đã chết!')

    // Thông báo qua Facebook Messenger
    // botMessenger.notifyOwner('bot_died', `Bot đã chết tại vị trí ${Math.floor(bot.entity.position.x)}, ${Math.floor(bot.entity.position.y)}, ${Math.floor(bot.entity.position.z)}`)

    // Lưu trạng thái hiện tại
    lastPosition = bot.entity.position ? { ...bot.entity.position } : null

    if (isFollowing) {
      lastMode = 'following'
      lastTargetPlayerName = targetPlayer?.username || ''
    } else if (isProtecting) {
      lastMode = 'protecting'
      lastTargetPlayerName = targetPlayer?.username || ''
    } else if (autoFarmActive) {
      lastMode = 'farming'
    } else if (autoFishingActive) {
      lastMode = 'fishing'
    } else if (autoMiningActive) {
      lastMode = 'mining'
    } else {
      lastMode = 'idle'
    }

    console.log(`💾 Đã lưu trạng thái: ${lastMode}, target: ${lastTargetPlayerName}`)
    bot.chat('💀 Tớ chết rồi! Sẽ quay lại ngay...')
  })

  bot.on('health', () => {
    // Handle health updates silently
  })

  // Note: The physicTick deprecation warning might be coming from plugins
  // We use the correct event name here, but plugins may still use the old one

  // ------------------ Trang bị ------------------
  function equipBestWeapon() {
    try {
      // Chế độ thường - vũ khí cận chiến
      const weapons = bot.inventory.items().filter(item => 
        item.name.includes('sword') || 
        item.name.includes('axe') || 
        item.name.includes('pickaxe') ||
        item.name.includes('shovel')
      )

      if (weapons.length > 0) {
        // Sort by attack damage if available, otherwise by item tier
        const bestWeapon = weapons.sort((a, b) => {
          const getTier = (name: string) => {
            if (name.includes('netherite')) return 5
            if (name.includes('diamond')) return 4
            if (name.includes('iron')) return 3
            if (name.includes('stone')) return 2
            if (name.includes('wood')) return 1
            return 0
          }
          return getTier(b.name) - getTier(a.name)
        })[0]

        if (!bot.heldItem || bot.heldItem.name !== bestWeapon.name) {
          bot.equip(bestWeapon, 'hand').catch(() => {})
        }
      }
    } catch (error) {
      console.log('Lỗi trang bị vũ khí:', error)
    }
  }

  // Bow functions removed

  // Kiểm tra vật cản giữa bot và target (raycast) - FIXED VERSION
  function hasLineOfSight(target: any): boolean {
    try {
      if (!target || !target.position) return false

      const botPos = bot.entity.position
      const targetPos = target.position

      // Điều chỉnh vị trí kiểm tra: mắt bot và trung tâm target
      const from = new Vec3(botPos.x, botPos.y + 1.6, botPos.z) // Mắt bot (1.6 blocks cao)
      const to = new Vec3(targetPos.x, targetPos.y + 0.5, targetPos.z) // Trung tâm target

      const distance = from.distanceTo(to)
      if (distance < 2) return true // Quá gần thì luôn có line of sight

      // Tính vector hướng
      const direction = to.clone().subtract(from).normalize()

      // Kiểm tra từng 0.5 block dọc theo đường
      const steps = Math.floor(distance * 2)
      for (let i = 1; i < steps; i++) {
        const checkPoint = from.clone().add(direction.clone().scale(i * 0.5))
        const block = bot.blockAt(checkPoint.floor())

        // Kiểm tra block rắn cản đường
        if (block && block.name !== 'air') {
          // Cho phép bắn qua các block không rắn
          const passableBlocks = [
            'water', 'lava', 'grass', 'tall_grass', 'fern', 'large_fern',
            'flower', 'dandelion', 'poppy', 'rose', 'vine', 'snow',
            'snow_layer', 'torch', 'redstone_torch', 'lever', 'button',
            'pressure_plate', 'tripwire', 'string', 'web', 'fire'
          ]

          const isPassable = passableBlocks.some(passable => 
            block.name.includes(passable)
          )

          if (!isPassable && block.boundingBox === 'block') {
            console.log(`🚫Vật cản: ${block.name} tại ${checkPoint.x.toFixed(1)}, ${checkPoint.y.toFixed(1)}, ${checkPoint.z.toFixed(1)}`)
            return false
          }
        }
      }

      return true // Không có vật cản
    } catch (error) {
      console.log('⚠️ Lỗi kiểm tra line of sight:', error)
      return true // Cho phép tấn công nếu có lỗi để tránh block hoàn toàn
    }
  }

  // Ranged attack function removed

  // Hàm tấn công cận chiến SPAM CỰC NHANH - tấn công liên tục không ngừng
  function meleeAttack(target: any, distance: number): boolean {
    if (!target || !target.isValid || !target.position) return false

    try {
      // Ngắm mục tiêu trước khi tấn công cận chiến
      const targetPos = target.position.clone()
      targetPos.y += target.height * 0.5 // Ngắm vào trung tâm để chính xác hơn

      // Đảm bảo không nhìn xuống đất trong cận chiến
      const botEyeY = bot.entity.position.y + 1.6
      if (targetPos.y < botEyeY - 0.8) {
        targetPos.y = botEyeY - 0.5
      }

      // Ngắm cực nhanh
      bot.lookAt(targetPos, false)

      // Tấn công - giảm xuống để tránh spam
      for (let i = 0; i < 3; i++) {
        bot.attack(target)
      }

      // Bật sprint để tăng damage và tốc độ
      bot.setControlState('sprint', true)

      // Tấn công spam (đã loại bỏ log để tránh spam console)
      return true
    } catch (error) {
      console.log('❌ Lỗi tấn công cận chiến:', error)
      return false
    }
  }

  function equipBestArmor() {
    try {
      const armorSlots: {[key: string]: any} = {
        head: null,
        torso: null,
        legs: null,
        feet: null
      }

      for (const item of bot.inventory.items()) {
        if (item.name.includes('helmet') && (!armorSlots.head || item.maxDurability > armorSlots.head.maxDurability)) {
          armorSlots.head = item
        } else if (item.name.includes('chestplate') && (!armorSlots.torso || item.maxDurability > armorSlots.torso.maxDurability)) {
          armorSlots.torso = item
        } else if (item.name.includes('leggings') && (!armorSlots.legs || item.maxDurability > armorSlots.legs.maxDurability)) {
          armorSlots.legs = item
        } else if (item.name.includes('boots') && (!armorSlots.feet || item.maxDurability > armorSlots.feet.maxDurability)) {
          armorSlots.feet = item
        }
      }

      // Equip armor
      Object.entries(armorSlots).forEach(([slot, item]) => {
        if (item) {
          const destination = slot === 'torso' ? 'torso' : slot
          bot.equip(item, destination as any).catch(() => {})
        }
      })
    } catch (error) {
      console.log('Lỗi trang bị giáp:', error)
    }
  }

  async function equipBestTool() {
    try {
      const pickaxes = bot.inventory.items().filter(item => item.name.includes('pickaxe'))

      if (pickaxes.length > 0) {
        const priority = ['netherite', 'diamond', 'iron', 'stone', 'wooden']
        let bestPickaxe = pickaxes[0]

        for (const material of priority) {
          const pickaxe = pickaxes.find(p => p.name.includes(material))
          if (pickaxe) {
            bestPickaxe = pickaxe
            break
          }
        }

        if (!bot.heldItem || bot.heldItem.name !== bestPickaxe.name) {
          await bot.equip(bestPickaxe, 'hand')
          console.log(`🔨 Trang bị ${bestPickaxe.name}`)
        }
        return true
      } else {
        console.log('Không có pickaxe nào để trang bị.')
        return false
      }
    } catch (error) {
      console.log('Lỗi trang bị tool:', error)
      return false
    }
  }

  function equipOffhand() {
    try {
      const totem = bot.inventory.items().find(item => item.name === 'totem_of_undying')
      const shield = bot.inventory.items().find(item => item.name.includes('shield'))

      if (totem) {
        bot.equip(totem, 'off-hand').catch(() => {})
        console.log(`✨ Bot đã trang bị Vật Tổ vào tay trái.`)
      } else if (shield) {
        bot.equip(shield, 'off-hand').catch(() => {})
        console.log(`🛡️ Bot đã trang bị Khiên vào tay trái.`)
      }
    } catch (error) {
      console.log('Lỗi trang bị offhand:', error)
    }
  }

  // Helper function để kiểm tra có nên chặn hoạt động khi câu cá không
  function isBlockedByFishing() {
    return autoFishingActive && (autoEquipDisabled || autoItemCollectionDisabled)
  }

  // Xử lý respawn - quay lại vị trí cũ và tiếp tục chế độ
  async function handleRespawn() {
    // Chỉ xử lý nếu có trạng thái được lưu
    if (lastMode === 'idle' || !lastPosition) {
      return
    }

    console.log(`🔄 Bắt đầu khôi phục trạng thái: ${lastMode}`)

    // Đợi 3 giây để bot ổn định sau khi respawn
    setTimeout(async () => {
      try {
        // Kiểm tra quyền /tp nếu chưa biết
        if (hasTpPermission === null) {
          console.log('🔍 Kiểm tra quyền /tp...')
          const currentPos = bot.entity.position
          bot.chat(`/tp ${bot.username} ${Math.floor(currentPos.x)} ${Math.floor(currentPos.y + 1)} ${Math.floor(currentPos.z)}`)

          // Kiểm tra sau 2 giây
          setTimeout(() => {
            const newPos = bot.entity.position
            const moved = Math.abs(newPos.y - currentPos.y) > 0.5

            if (moved) {
              hasTpPermission = true
              console.log('✅ Bot có quyền /tp')
              // Thực hiện teleport về vị trí cũ
              performRespawnTeleport()
            } else {
              hasTpPermission = false
              tpFailCount++
              console.log('❌ Bot không có quyền /tp')
              bot.chat('🥺 Tớ không có quyền /tp để quay lại vị trí cũ. Dừng hoạt động!')
              resetRespawnState()
            }
          }, 2000)
        } else if (hasTpPermission === true) {
          // Có quyền /tp, thực hiện ngay
          performRespawnTeleport()
        } else {
          // Không có quyền /tp
          tpFailCount++
          if (tpFailCount >= 3) {
            bot.chat('🥺 Tớ không có quyền /tp. Dừng tất cả hoạt động!')
            resetRespawnState()
            return
          }
          console.log('❌ Bỏ qua respawn vì không có quyền /tp')
        }
      } catch (error) {
        console.log('❌ Lỗi khi kiểm tra quyền /tp:', error)
        resetRespawnState()
      }
    }, 3000)
  }

  function performRespawnTeleport() {
    if (!lastPosition) return

    console.log(`🚀 Teleport về vị trí cũ: ${Math.floor(lastPosition.x)}, ${Math.floor(lastPosition.y)}, ${Math.floor(lastPosition.z)}`)
    const tpCommand = `/tp ${bot.username} ${Math.floor(lastPosition.x)} ${Math.floor(lastPosition.y)} ${Math.floor(lastPosition.z)}`
    bot.chat(tpCommand)

    // Kiểm tra thành công sau 3 giây
    setTimeout(() => {
      const currentPos = bot.entity.position
      const distance = Math.sqrt(
        Math.pow(currentPos.x - lastPosition!.x, 2) +
        Math.pow(currentPos.y - lastPosition!.y, 2) +
        Math.pow(currentPos.z - lastPosition!.z, 2)
      )

      if (distance < 10) {
        console.log('✅ Teleport thành công, khôi phục chế độ')
        restorePreviousMode()
      } else {
        console.log('❌ Teleport thất bại, thử lại...')
        tpFailCount++
        if (tpFailCount < 3) {
          setTimeout(() => performRespawnTeleport(), 2000)
        } else {
          console.log('❌ Teleport thất bại quá nhiều lần, dừng khôi phục')
          resetRespawnState()
        }
      }
    }, 3000)
  }

  function restorePreviousMode() {
    console.log(`🔄 Khôi phục chế độ: ${lastMode}`)

    switch (lastMode) {
      case 'following':
        if (lastTargetPlayerName) {
          bot.chat(`🔄 Quay lại theo ${lastTargetPlayerName}!`)
          startFollowingPlayer(lastTargetPlayerName)
        }
        break

      case 'protecting':
        if (lastTargetPlayerName) {
          bot.chat(`🔄 Quay lại bảo vệ ${lastTargetPlayerName}!`)
          startProtectingPlayer(lastTargetPlayerName)
        }
        break

      case 'farming':
        bot.chat('🔄 Quay lại auto farm!')
        startAutoFarmAll()
        break

      case 'fishing':
        bot.chat('🔄 Quay lại auto câu!')
        startSmartAutoFishing()
        break

      case 'mining':
        if (targetOreType) {
          bot.chat(`🔄 Quay lại auto mine ${targetOreType}!`)
          startAutoMining(targetOreType)
        }
        break

      default:
        console.log('🔄 Không có chế độ để khôi phục')
        break
    }

    // Reset trạng thái sau khi khôi phục
    resetRespawnState()
  }

  function resetRespawnState() {
    lastPosition = null
    lastMode = 'idle'
    lastTargetPlayerName = ''
    tpFailCount = 0
  }

  // Tự động trang bị định kỳ (chặn khi đang câu)
  setInterval(() => {
    // Không trang bị khi đang câu cá
    if (isBlockedByFishing()) {
      return
    }

    equipBestWeapon()
    equipBestArmor()
    equipOffhand()
  }, 10000)

  // ------------------ Auto eat ------------------
  function autoEatSetup() {
    console.log('🍽️ Thiết lập auto eat cho tất cả chức năng')

    // Auto eat chạy liên tục cho tất cả chế độ
    setInterval(() => {
      // Kiểm tra có nên ăn không
      const health = bot.health
      const food = bot.food
      const currentTime = Date.now()

      // Điều kiện ăn: máu dưới 16 hoặc đói dưới 16, không đang ăn, đã đủ thời gian từ lần ăn trước
      const shouldEat = (health < 16 || food < 16) && !isEating && (currentTime - lastEatTime > 3000)

      // Kiểm tra có mob gần không để quyết định có ăn an toàn không
      const hasNearbyMob = bot.nearestEntity((entity: any) => {
        if (!entity || !entity.position) return false
        const distance = bot.entity.position.distanceTo(entity.position)
        return distance <= 6 && entity.type === 'mob' && !entity.name?.includes('villager')
      })

      // Chỉ ăn khi an toàn (không có mob gần) hoặc máu quá thấp (khẩn cấp)
      const canEatSafely = !hasNearbyMob || health < 6

      if (shouldEat && canEatSafely) {
        tryEatFood()
      }
    }, 2000) // Kiểm tra mỗi 2 giây
  }

  // Hàm ăn thức ăn cải tiến
  async function tryEatFood() {
    if (isEating) return

    // Tìm thức ăn trong inventory - LOẠI TRỪ fishing_rod và các item không phải thức ăn
    const foodItems = bot.inventory.items().filter(item => {
      const itemName = item.name.toLowerCase()

      // LOẠI TRỪ các item không phải thức ăn
      if (itemName.includes('fishing_rod') ||
          itemName.includes('pickaxe') ||
          itemName.includes('shovel') ||
          itemName.includes('axe') ||
          itemName.includes('sword') ||
          itemName.includes('bow') ||
          itemName.includes('arrow') ||
          itemName.includes('bucket') ||
          itemName.includes('bottle') ||
          itemName.includes('helmet') ||
          itemName.includes('chestplate') ||
          itemName.includes('leggings') ||
          itemName.includes('boots') ||
          itemName.includes('shield') ||
          itemName.includes('totem')) {
        return false
      }

      // CHỈ CHẤP NHẬN thức ăn thật
      return itemName.includes('bread') || 
             itemName.includes('apple') || 
             itemName.includes('meat') ||
             (itemName.includes('fish') && !itemName.includes('fishing')) ||
             itemName.includes('potato') ||
             itemName.includes('carrot') ||
             itemName.includes('beef') ||
             itemName.includes('pork') ||
             itemName.includes('chicken') ||
             itemName.includes('steak') ||
             itemName.includes('cooked') ||
             itemName.includes('golden_apple') ||
             itemName.includes('enchanted_golden_apple') ||
             itemName.includes('cookie') ||
             itemName.includes('cake') ||
             itemName.includes('mutton') ||
             itemName.includes('salmon') ||
             itemName.includes('cod')
    })

    if (foodItems.length === 0) {
      // Không có thức ăn
      if (bot.health < 6) {
        console.log('🥺 Bot thiếu thức ăn và máu yếu!')
      }
      return
    }

    try {
      isEating = true

      // Sắp xếp thức ăn từ tốt đến tệ
      const sortedFood = foodItems.sort((a, b) => {
        const getFoodValue = (name: string) => {
          if (name.includes('enchanted_golden_apple')) return 15
          if (name.includes('golden_apple')) return 10
          if (name.includes('steak') || name.includes('cooked_beef')) return 9
          if (name.includes('cooked_pork') || name.includes('porkchop')) return 8
          if (name.includes('cooked_chicken')) return 7
          if (name.includes('cooked_salmon') || name.includes('cooked_cod')) return 6
          if (name.includes('bread')) return 5
          if (name.includes('cooked_mutton')) return 4
          if (name.includes('apple')) return 3
          if (name.includes('carrot') || name.includes('potato')) return 2
          if (name.includes('raw_beef') || name.includes('raw_pork') || name.includes('raw_chicken')) return 1
          return 0
        }
        return getFoodValue(b.name) - getFoodValue(a.name)
      })

      // Lưu vũ khí hiện tại để trang bị lại sau khi ăn
      const currentWeapon = bot.heldItem

      // Trang bị thức ăn
      await bot.equip(sortedFood[0], 'hand')

      // Ăn với timeout để tránh hanging
      const eatPromise = bot.consume()
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Eating timeout')), 4000)
      )

      await Promise.race([eatPromise, timeoutPromise])

      lastEatTime = Date.now()
      console.log(`🍞 Bot đã ăn ${sortedFood[0].name} - HP: ${bot.health}/20, Food: ${bot.food}/20`)

      // Trang bị lại vũ khí sau khi ăn (nếu có)
      if (currentWeapon && currentWeapon.name && !isBlockedByFishing()) {
        try {
          await bot.equip(currentWeapon, 'hand')
        } catch (error) {
          // Nếu không thể trang bị lại vũ khí cũ, trang bị vũ khí tốt nhất
          equipBestWeapon()
        }
      }

      // Đợi một chút trước khi có thể ăn lại
      setTimeout(() => { 
        isEating = false 
      }, 2000)

    } catch (error) {
      console.log('⚠️ Không thể ăn thức ăn:', error)
      isEating = false

      // Nếu lỗi ăn, thử trang bị lại vũ khí
      if (!isBlockedByFishing()) {
        equipBestWeapon()
      }
    }
  }

  // ------------------ Nhặt item ------------------
  let itemCollectionDisabled = false // Biến để tắt nhặt đồ khi dừng

  function collectNearbyItems() {
    setInterval(() => {
      // Chặn nhặt đồ khi đang câu cá hoặc khi bị disabled
      if (isBlockedByFishing() || itemCollectionDisabled) {
        return
      }

      try {
        const entities = Object.values(bot.entities)
        for (const entity of entities) {
          if (entity.name === 'item' && entity.position && bot.entity.position.distanceTo(entity.position) < 5) {
            bot.lookAt(entity.position, true).catch(() => {})
            bot.collectBlock.collect(entity).catch(() => {})
          }
        }
      } catch (error) {
        // Ignore errors
      }
    }, 2000)
  }

  // Track và chat item name khi nhận được
  bot.on('playerCollect', (collector: any, collected: any) => {
    if (collector.username === bot.username && collected.metadata) {
      const itemName = collected.metadata.itemName || collected.name || 'Unknown item'
      console.log(`🎁 Bot đã nhận: ${itemName}`)
      // Bỏ chat để tránh spam - chỉ log trong console
    }
  })

  // ------------------ Random Status Updates ------------------
  function startStatusUpdates() {
    setInterval(() => {
      // Removed flirting, now only provides status updates when needed
      if (Math.random() < 0.1) { // 10% chance every 30s for status
        const statusMessages = [
          "🤖 Tớ đang hoạt động bình thường!",
          "⚡ Hệ thống bot stable!",
          "🔋 Bot ready cho commands!",
          "🌟 Mọi thứ OK!"
        ]
        const randomMessage = statusMessages[Math.floor(Math.random() * statusMessages.length)]
        console.log(`Status: ${randomMessage}`)
      }
    }, 30000) // 30 giây một lần
  }

  // ------------------ SMART AUTO FISHING ------------------
  // Biến tracking cho smart auto fishing
  let isFishing = false
  let fishingInterval: NodeJS.Timeout | null = null
  let currentHook: any = null 
  let hookCheckInterval: NodeJS.Timeout | null = null
  let fishingStartTime = 0
  let hasFishBitten = false
  let lastHookPosition: any = null

  function startSmartAutoFishing() {
    // Dừng các hoạt động khác TRƯỚC khi bắt đầu câu
    stopFollowing()
    stopProtecting()
    autoFarmActive = false

    // Kích hoạt chế độ câu cá thông minh
    autoFishingActive = true
    autoItemCollectionDisabled = true  // Tạm dừng nhặt đồ
    autoEquipDisabled = true           // Tạm dừng tự động trang bị
    itemCollectionDisabled = false     // Bật lại nhặt đồ cho fishing

    isFishing = false
    currentHook = null
    bobberThrowCount = 0 // Reset số đếm âm thanh fishing_bobber.throw cho lần câu này

    bot.chat('🎣 Bắt đầu auto câu thông minh! Tớ chỉ cầm cần câu thôi nè~ ✨')
    console.log('🎣 Smart Auto Fishing - Activated')

    if (fishingInterval) {
      clearInterval(fishingInterval)
    }

    fishingInterval = setInterval(async () => {
      if (!autoFishingActive) {
        clearInterval(fishingInterval!)
        fishingInterval = null
        return
      }

      // Nếu đang câu thì không làm gì cả, chỉ đợi
      if (isFishing) {
        return
      }

      try {
        // BƯỚC 1: Kiểm tra cần câu
        const fishingRod = bot.inventory.items().find(item => item.name.includes('fishing_rod'))

        if (!fishingRod) {
          bot.chat('🥺 Không có cần câu! Cần cần câu để hoạt động nè!')
          stopSmartAutoFishing()
          return
        }

        // BƯỚC 2: Chỉ cầm cần câu - bỏ tất cả đồ khác
        if (!bot.heldItem || !bot.heldItem.name.includes('fishing_rod')) {
          await bot.equip(fishingRod, 'hand')
          console.log('🎣 Chỉ cầm cần câu:', fishingRod.name)
          await new Promise(resolve => setTimeout(resolve, 800))
        }

        // BƯỚC 3: Tìm nước để câu
        const waterBlock = bot.findBlock({
          matching: (block) => block && (block.name === 'water'),
          maxDistance: 20,
          useExtraInfo: true
        })

        if (waterBlock) {
          // Di chuyển đến gần nước nếu cần
          if (bot.entity.position.distanceTo(waterBlock.position) > 5) {
            const movements = new Movements(bot)
            movements.allowSprinting = true
            bot.pathfinder.setMovements(movements)
            const nearWaterGoal = new goals.GoalNear(waterBlock.position.x, waterBlock.position.y, waterBlock.position.z, 4)
            bot.pathfinder.setGoal(nearWaterGoal)
            await new Promise(resolve => setTimeout(resolve, 2000))
            bot.pathfinder.setGoal(null)
          }

          // BƯỚC 4: Thả câu xuống nước  
          await bot.lookAt(waterBlock.position.offset(0.5, 0.5, 0.5), true)
          await new Promise(resolve => setTimeout(resolve, 400))

          console.log('🎣 Thả cần xuống nước!')
          isFishing = true
          currentHook = null
          bobberThrowCount = 0 // Reset đếm âm thanh fishing_bobber.throw cho lần câu này
          bot.activateItem() // Thả phao

          // BƯỚC 5: Setup event listeners cho fishing
          setupFishingEventListeners()

          // BƯỚC 6: Đợi 4 giây trước khi theo dõi
          setTimeout(() => {
            if (!autoFishingActive || !isFishing) return

            // Tìm fishing hook entity với nhiều lần thử
            let attempts = 0
            const maxAttempts = 10
            const findHook = () => {
              attempts++
              currentHook = Object.values(bot.entities).find(entity => 
                (entity.name === 'fishing_bobber' || entity.name === 'fishing_hook') &&
                entity.position &&
                bot.entity.position.distanceTo(entity.position) < 15
              )

              if (currentHook) {
                console.log('✅ Đã tìm thấy phao, bắt đầu theo dõi chuyển động...')
                startSmartHookWatcher()
              } else if (attempts < maxAttempts) {
                console.log(`⚠️ Không thấy phao, thử lại... (${attempts}/${maxAttempts})`)
                setTimeout(findHook, 500) // Thử lại sau 0.5 giây
              } else {
                console.log('❌ Không thể tìm thấy phao sau nhiều lần thử, thả cần lại')
                isFishing = false
              }
            }
            findHook()
          }, 4000) // Đợi 4 giây như yêu cầu trước khi theo dõi

        } else {
          bot.chat('🥺 Không tìm thấy nước gần! Cần tìm ao, sông hoặc biển~')
          stopSmartAutoFishing()
        }

      } catch (error) {
        console.log('❌ Lỗi smart fishing:', error)
        bot.chat('😵 Có lỗi khi câu cá! Thử lại sau~')
        isFishing = false
      }
    }, 6000) // Kiểm tra mỗi 6 giây
  }

  // Alias để tương thích với lệnh chat cũ
  function startAutoFishing() {
    return startSmartAutoFishing()
  }

  // Hàm theo dõi fishing hook metadata - ƯU TIÊN SỐ 1
  let lastHookMetadata: any = null

  // Hệ thống phát hiện cá cắn thông minh - FIXED VERSION
  let fishingIndicators = {
    particleCount: 0,
    velocityDetections: 0,
    positionChanges: 0,
    strongMovements: 0,
    lastResetTime: Date.now()
  }

  function startSmartHookWatcher() {
    if (hookCheckInterval) {
      clearInterval(hookCheckInterval)
    }

    fishingStartTime = Date.now()
    hasFishBitten = false
    lastHookPosition = currentHook.position ? { ...currentHook.position } : null

    // Reset indicators khi bắt đầu fishing mới
    fishingIndicators = {
      particleCount: 0,
      velocityDetections: 0,
      positionChanges: 0,
      strongMovements: 0,
      lastResetTime: Date.now()
    }

    console.log('🎣 Bắt đầu smart hook watcher, đợi 6 giây trước khi phát hiện...')

    hookCheckInterval = setInterval(() => {
      if (!autoFishingActive || !isFishing || hasFishBitten) {
        if (hookCheckInterval) {
          clearInterval(hookCheckInterval)
          hookCheckInterval = null
        }
        return
      }

      const currentTime = Date.now()
      const fishingDuration = currentTime - fishingStartTime

      // Tìm hook entity hiện tại
      const hookEntity = Object.values(bot.entities).find(entity => 
        entity.id === currentHook.id && 
        (entity.name === 'fishing_bobber' || entity.name === 'fishing_hook')
      )

      if (!hookEntity) {
        // Hook biến mất = đã câu được cá (chỉ sau 6 giây)
        if (fishingDuration > 6000) {
          console.log('🐟 PHAO BIẾN MẤT - ĐÃ CÂU ĐƯỢC CÁ!')
          hasFishBitten = true
          handleSmartFishCaught()
        }
        return
      }

      // CHỈ BẮT ĐẦU PHÁT HIỆN SAU 6 GIÂY ĐỂ TRÁNH GIẬT CẦN SỚM
      if (fishingDuration < 6000) {
        // Cập nhật vị trí để chuẩn bị
        if (hookEntity.position) {
          lastHookPosition = { ...hookEntity.position }
        }
        return
      }

      // PHƯƠNG PHÁP 1: Theo dõi chuyển động Y (phao bị kéo xuống)
      if (hookEntity.position && lastHookPosition) {
        const yChange = lastHookPosition.y - hookEntity.position.y // Dương = phao chìm xuống
        const distanceMoved = Math.sqrt(
          (hookEntity.position.x - lastHookPosition.x) ** 2 +
          (hookEntity.position.y - lastHookPosition.y) ** 2 +
          (hookEntity.position.z - lastHookPosition.z) ** 2
        )

        // Log debug mỗi 2 giây (bớt spam)
        if (fishingDuration % 2000 < 100) {
          console.log(`🎣 DEBUG: Y: ${yChange.toFixed(3)}, Dist: ${distanceMoved.toFixed(3)}, Time: ${(fishingDuration/1000).toFixed(1)}s, Sounds: ${bobberThrowCount}`)
        }

        // ĐẾM CÁC DẤU HIỆU CÁ CẮN (chỉ sau 6 giây) - THÔNG SỐ TỐI ƯU
        if (yChange > 0.04 || distanceMoved > 0.05) {
          fishingIndicators.positionChanges++
        }
        if (yChange > 0.25 || distanceMoved > 0.25) {
          fishingIndicators.strongMovements++
        }

        // ĐIỀU KIỆN RÚT CẦN - THÔNG SỐ TỐI ƯU

        // ĐIỀU KIỆN 1: Âm thanh fishing_bobber.throw lần 2 + chuyển động thật (ngưỡng cá cắn)
        if (bobberThrowCount >= 2 && (yChange > 0.25 || distanceMoved > 0.25)) {
          console.log(`🐟 ÂM THANH LẦN 2 + CÁ CẮN THẬT! Y: ${yChange.toFixed(3)}, D: ${distanceMoved.toFixed(3)}`)
          handleSmartFishCaught()
          return
        }

        // ĐIỀU KIỆN 2: Chuyển động cực mạnh (chắc chắn có cá) - Ngưỡng gần như chắc chắn
        if (yChange > 0.40 || distanceMoved > 0.40) {
          console.log(`🐟 CHUYỂN ĐỘNG CỰC MẠNH! Y: ${yChange.toFixed(3)}, Distance: ${distanceMoved.toFixed(3)}`)
          handleSmartFishCaught()
          return
        }
      }

      // PHƯƠNG PHÁP 2: Velocity detection - THÔNG SỐ TỐI ƯU
      if (hookEntity.velocity && fishingDuration > 6000) {
        const velocityMagnitude = Math.sqrt(
          hookEntity.velocity.x ** 2 + 
          hookEntity.velocity.y ** 2 + 
          hookEntity.velocity.z ** 2
        )

        // Chỉ đếm velocity trên ngưỡng nhiễu (>0.05)
        if (velocityMagnitude > 0.05) {
          fishingIndicators.velocityDetections++
        }

        // Velocity cá cắn + âm thanh (ngưỡng tối ưu >0.25)
        if (velocityMagnitude > 0.25 && bobberThrowCount >= 2) {
          console.log(`🐟 VELOCITY CÁ CẮN + ÂM THANH! V: ${velocityMagnitude.toFixed(3)}`)
          handleSmartFishCaught()
          return
        }

        // Velocity gần như chắc chắn (>0.40)
        if (velocityMagnitude > 0.40) {
          console.log(`🐟 VELOCITY CHẮC CHẮN! V: ${velocityMagnitude.toFixed(3)}`)
          handleSmartFishCaught()
          return
        }
      }

      // Cập nhật vị trí cuối của phao
      if (hookEntity.position) {
        lastHookPosition = { ...hookEntity.position }
      }

      // HỆ THỐNG DỰ PHÒNG - CHỈ KÍCH HOẠT MUỘN HƠN
      const totalIndicators = fishingIndicators.particleCount + fishingIndicators.velocityDetections + fishingIndicators.positionChanges

      // DỰ PHÒNG 1: Sau 10 giây + nhiều dấu hiệu mạnh
      if (fishingDuration > 10000 && fishingIndicators.strongMovements >= 5) {
        console.log(`🐟 DỰ PHÒNG (10s): Strong movements: ${fishingIndicators.strongMovements}`)
        handleSmartFishCaught()
        return
      }

      // DỰ PHÒNG 2: Sau 15 giây + có dấu hiệu + âm thanh
      if (fishingDuration > 15000 && totalIndicators >= 10 && bobberThrowCount >= 1) {
        console.log(`🐟 DỰ PHÒNG (15s): Total: ${totalIndicators}, Sounds: ${bobberThrowCount}`)
        handleSmartFishCaught()
        return
      }

      // Timeout sau 25 giây (giảm từ 30 giây)
      if (fishingDuration > 25000) {
        console.log('⏰ Timeout 25s - rút cần và thả lại')
        try {
          bot.activateItem()
          console.log('🎣 Đã rút cần timeout')
        } catch (error) {
          console.log('❌ Lỗi rút cần timeout:', error)
        }
        isFishing = false
        currentHook = null
        bobberThrowCount = 0
        setTimeout(() => {
          if (autoFishingActive && !isFishing) {
            console.log('🎣 Thả cần mới sau timeout...')
          }
        }, 1000)
      }

    }, 100) // Tăng interval từ 30ms lên 100ms để giảm load
  }

  // Setup fishing event listeners để backup detection
  function setupFishingEventListeners() {
    console.log('🎣 Setting up fishing event listeners...')

    // Clear tất cả sound listeners cũ trước khi thêm mới
    bot.removeAllListeners('soundEffectHeard')
    bot.removeAllListeners('particle')
    console.log('🧹 Đã xóa tất cả sound listeners cũ')

    // Listen for sound effects
    const soundListener = (sound: any, position: any) => {
      if (!autoFishingActive || !isFishing || hasFishBitten) return

      const fishingDuration = Date.now() - fishingStartTime
      if (fishingDuration < 4000) return // Chỉ listen sau 4 giây

      // Console để debug âm thanh (nhưng không log fishing_bobber.throw để giảm spam)
      if (!sound.includes('entity.fishing_bobber.throw') && 
          !sound.includes('.step') && 
          !sound.includes('.converted') &&
          !sound.includes('.aggro')) {
        console.log(`🔊 Heard sound: ${sound}, position:`, position)
      }

      // Đếm số lần âm thanh fishing_bobber.throw xuất hiện
      if (sound.includes('entity.fishing_bobber.throw')) {
        bobberThrowCount++
        console.log(`🎣 Âm thanh fishing_bobber.throw lần ${bobberThrowCount}`)

        // Chỉ rút cần khi âm thanh này xuất hiện lần thứ 2 (cá cắn thật)
        if (bobberThrowCount === 2) {
          console.log('🐟 SOUND DETECTION - CÁ CẮN THẬT! (Lần 2)')
          handleSmartFishCaught()
        }
        return // Thoát khỏi function sau khi xử lý
      }

      // Bỏ qua các âm thanh khác không liên quan
      if (sound.includes('entity.fishing_bobber.retrieve') ||
          sound.includes('.step') ||
          sound.includes('.aggro') ||
          sound.includes('.converted') ||
          sound.includes('.break')) {
        return
      }

      // Phương pháp dự phòng: Chỉ phát hiện âm thanh water splash thực sự từ cá cắn
      if (sound && (sound.includes('entity.generic.splash') || 
                   sound.includes('block.water.ambient') ||
                   sound.includes('entity.bobber.splash'))) {
        console.log('🐟 BACKUP SOUND DETECTION - CÁ CẮN!')
        handleSmartFishCaught()
      }
    }

    // Listen for particles near fishing hook - CHỈ ĐỂ THEO DÕI, KHÔNG RÚT CẦN
    const particleListener = (particle: any) => {
      if (!autoFishingActive || !isFishing || hasFishBitten) return
      if (!currentHook) return

      const fishingDuration = Date.now() - fishingStartTime
      if (fishingDuration < 4000) return

      // Check if particle is near fishing hook
      if (particle.position && currentHook.position) {
        const distance = Math.sqrt(
          (particle.position.x - currentHook.position.x) ** 2 +
          (particle.position.y - currentHook.position.y) ** 2 +
          (particle.position.z - currentHook.position.z) ** 2
        )

        if (distance < 3) {
          // CHỈ LOG ĐỂ THEO DÕI - KHÔNG RÚT CẦN
          if (particle.name && (particle.name.includes('splash') || particle.name.includes('fishing'))) {
            console.log(`🌊 Particle ${particle.name} gần phao (${distance.toFixed(2)}m) - chờ âm thanh...`)
          }
        }
      }
    }

    // Thêm listeners
    bot.on('soundEffectHeard', soundListener)
    bot.on('particle', particleListener)

    // Lưu references để cleanup sau này (sẽ được cleanup trong stopSmartAutoFishing)
    // Listeners sẽ được remove bằng removeAllListeners khi setup lại
  }

  function handleSmartFishCaught() {
    if (!isFishing) return
    if (hasFishBitten) return // Tránh xử lý trùng lặp

    hasFishBitten = true

    // Dừng timer theo dõi ngay lập tức
    if (hookCheckInterval) {
      clearInterval(hookCheckInterval)
      hookCheckInterval = null
    }

    console.log('🎣 Phát hiện cá cắn! Đang rút cần...')

    // Rút cần NGAY LẬP TỨC - không delay, không chat spam
    try {
      // Đảm bảo bot đang cầm cần câu
      const fishingRod = bot.inventory.items().find(item => item.name.includes('fishing_rod'))
      if (fishingRod && (!bot.heldItem || !bot.heldItem.name.includes('fishing_rod'))) {
        bot.equip(fishingRod, 'hand').then(() => {
          // Rút cần sau khi trang bị
          bot.activateItem()
          console.log('🎣 Đã rút cần sau khi trang bị!')
          // Chat chỉ 1 lần khi thành công
          bot.chat('🎣 Câu thành công! ✨')
        }).catch(err => {
          console.log('Lỗi trang bị cần khi rút:', err)
          bot.activateItem() // Thử rút dù sao
          bot.chat('🎣 Câu thành công! ✨')
        })
      } else {
        // Đã cầm cần câu rồi, rút ngay
        bot.activateItem()
        console.log('🎣 Đã rút cần!')
        // Chat chỉ 1 lần khi thành công
        bot.chat('🎣 Câu thành công! ✨')
      }
    } catch (error) {
      console.log('❌ Lỗi khi rút cần:', error)
      // Thử rút lần nữa
      setTimeout(() => {
        try {
          bot.activateItem()
          console.log('🎣 Thử rút cần lần 2')
          bot.chat('🎣 Câu thành công! ✨')
        } catch (e) {
          console.log('❌ Không thể rút cần:', e)
        }
      }, 200)
    }

    // Reset trạng thái
    isFishing = false
    currentHook = null
    lastHookPosition = null
    bobberThrowCount = 0 // Reset đếm âm thanh fishing_bobber.throw cho lần câu tiếp theo

    // Reset để câu tiếp - không có chat thêm
    setTimeout(() => {
      hasFishBitten = false
      fishingStartTime = 0
      lastHookPosition = null
      console.log('🎣 Sẵn sàng câu tiếp...')
    }, 1000)
  }

  // Alias để tương thích với code cũ
  function handleFishCaught() {
    return handleSmartFishCaught()
  }

  // Function đã có ở trên rồi, xóa duplicate này

  function stopSmartAutoFishing() {
    autoFishingActive = false
    autoItemCollectionDisabled = false  // Bật lại nhặt đồ
    autoEquipDisabled = false           // Bật lại tự động trang bị

    isFishing = false
    hasFishBitten = false
    bobberThrowCount = 0 // Reset đếm âm thanh fishing_bobber.throw

    if (fishingInterval) {
      clearInterval(fishingInterval)
      fishingInterval = null
    }

    if (hookCheckInterval) {
      clearInterval(hookCheckInterval)
      hookCheckInterval = null
    }

    currentHook = null
    lastHookPosition = null

    bot.chat('🎣 Dừng auto câu! Các chức năng khác hoạt động lại~')
    console.log('⏹️ Smart Auto Fishing - Deactivated')
    console.log('✅ Auto item collection: Enabled')
    console.log('✅ Auto equipment: Enabled')
  }

  // Alias để tương thích với code cũ
  function stopAutoFishing() {
    return stopSmartAutoFishing()
  }

  // ------------------ AUTO MINING ------------------
  function startAutoMining(oreType: string) {
    // Dừng các hoạt động khác trước khi bắt đầu mine
    stopFollowing()
    stopProtecting()
    if (autoFishingActive) stopAutoFishing()
    autoFarmActive = false

    autoMiningActive = true
    targetOreType = oreType.toLowerCase()
    currentMiningTarget = null

    bot.chat(`⛏️ Bắt đầu auto mine ${oreType}! Tớ sẽ tìm và đào tất cả ${oreType} gần đây!`)
    console.log(`🔥 Auto Mining ${oreType} - Activated`)

    if (miningInterval) {
      clearInterval(miningInterval)
    }

    miningInterval = setInterval(async () => {
      if (!autoMiningActive) {
        clearInterval(miningInterval!)
        miningInterval = null
        return
      }

      try {
        // Kiểm tra túi đồ có đầy không
        const inventoryFull = bot.inventory.emptySlotCount() <= 2
        if (inventoryFull) {
          bot.chat('🎒 Túi đồ đầy rồi! Dừng auto mine!')
          stopAutoMining()
          return
        }

        // Trang bị pickaxe tốt nhất
        if (!await equipBestTool()) {
          bot.chat('🥺 Không có pickaxe để đào!')
          stopAutoMining()
          return
        }

        // Tìm block quặng gần nhất - TĂNG KHOẢNG CÁCH LÊN 40 BLOCKS
        const oreBlock = bot.findBlock({
          matching: (block: any) => {
            if (!block) return false
            const blockName = block.name.toLowerCase()
            
            // Map các tên quặng thường gặp
            const oreNames = {
              'coal': ['coal_ore', 'deepslate_coal_ore'],
              'iron': ['iron_ore', 'deepslate_iron_ore'],
              'gold': ['gold_ore', 'deepslate_gold_ore', 'nether_gold_ore'],
              'diamond': ['diamond_ore', 'deepslate_diamond_ore'],
              'emerald': ['emerald_ore', 'deepslate_emerald_ore'],
              'redstone': ['redstone_ore', 'deepslate_redstone_ore'],
              'lapis': ['lapis_ore', 'deepslate_lapis_ore'],
              'copper': ['copper_ore', 'deepslate_copper_ore'],
              'stone': ['stone', 'cobblestone', 'deepslate'],
              'dirt': ['dirt', 'grass_block'],
              'sand': ['sand'],
              'gravel': ['gravel']
            }

            const targetOres = oreNames[targetOreType] || [targetOreType + '_ore', 'deepslate_' + targetOreType + '_ore']
            
            return targetOres.some(ore => blockName.includes(ore)) || blockName.includes(targetOreType)
          },
          maxDistance: 40, // TĂNG LÊN 40 BLOCKS ĐỂ TÌM KIẾM RỘNG HƠN
          useExtraInfo: true
        })

        if (oreBlock) {
          console.log(`⛏️ Tìm thấy ${oreBlock.name} tại ${oreBlock.position.x}, ${oreBlock.position.y}, ${oreBlock.position.z}`)
          
          // Di chuyển đến gần block - GIẢM KHOẢNG CÁCH TỪ 4.5 XUỐNG 3
          const distance = bot.entity.position.distanceTo(oreBlock.position)
          if (distance > 3) { // GIẢM TỪ 4.5 XUỐNG 3
            const movements = new Movements(bot)
            movements.canDig = true
            movements.allow1by1towers = true
            movements.allowParkour = true
            movements.allowSprinting = true
            bot.pathfinder.setMovements(movements)

            const goal = new goals.GoalNear(oreBlock.position.x, oreBlock.position.y, oreBlock.position.z, 2) // GIẢM TỪ 4 XUỐNG 2
            bot.pathfinder.setGoal(goal)
            
            // Đợi di chuyển - TĂNG THỜI GIAN CHỜ ĐỂ ĐẢM BẢO ĐẾN GẦN
            await new Promise(resolve => setTimeout(resolve, 2000))
          }

          // Đào block
          currentMiningTarget = oreBlock
          
          try {
            console.log(`⛏️ Bắt đầu đào ${oreBlock.name}...`)
            await bot.dig(oreBlock)
            console.log(`✅ Đã đào xong ${oreBlock.name}!`)
            
            // Thu thập item rơi - CẢI THIỆN THU THẬP VỚI PHẠM VI RỘNG HƠN
            // Đợi 0.5 giây để item spawn
            await new Promise(resolve => setTimeout(resolve, 500))
            
            // Thu thập nhiều lần để đảm bảo nhặt hết - ƯU TIÊN THU THẬP
            for (let i = 0; i < 5; i++) { // TĂNG SỐ LẦN THU THẬP TỪ 3 LÊN 5
              const entities = Object.values(bot.entities)
              
              // Sắp xếp item theo khoảng cách để ưu tiên nhặt gần trước
              const itemEntities = entities
                .filter(entity => entity.name === 'item' && entity.position)
                .sort((a, b) => {
                  const distA = bot.entity.position.distanceTo(a.position!)
                  const distB = bot.entity.position.distanceTo(b.position!)
                  return distA - distB
                })
              
              for (const entity of itemEntities) {
                const itemDistance = bot.entity.position.distanceTo(entity.position!)
                if (itemDistance < 10) { // TĂNG PHẠM VI THU THẬP TỪ 8 LÊN 10
                  try {
                    await bot.collectBlock.collect(entity)
                    console.log(`🎁 Nhặt được item từ ${oreBlock.name} (${itemDistance.toFixed(1)}m)`)
                  } catch (collectError) {
                    // Bỏ qua lỗi thu thập
                  }
                }
              }
              // Đợi giữa các lần thu thập
              if (i < 4) await new Promise(resolve => setTimeout(resolve, 200)) // GIẢM DELAY TỪ 300 XUỐNG 200
            }

          } catch (error) {
            console.log('❌ Lỗi đào block:', error)
          }

          currentMiningTarget = null

        } else {
          // Không tìm thấy quặng, di chuyển ngẫu nhiên để tìm - GIẢM PHẠM VI DI CHUYỂN
          if (Math.random() < 0.3) { // GIẢM TỪ 40% XUỐNG 30%
            const randomX = Math.floor(Math.random() * 11) - 5 // GIẢM TỪ 21 XUỐNG 11 (phạm vi -5 đến +5)
            const randomZ = Math.floor(Math.random() * 11) - 5
            const currentPos = bot.entity.position
            const goal = new goals.GoalXZ(currentPos.x + randomX, currentPos.z + randomZ)
            bot.pathfinder.setGoal(goal)
            console.log(`🔍 Không thấy ${targetOreType}, di chuyển tìm kiếm gần hơn...`)
          }
        }

      } catch (error) {
        console.log('❌ Lỗi auto mining:', error)
        bot.pathfinder.setGoal(null)
      }
    }, 2500) // GIẢM INTERVAL TỪ 3000 XUỐNG 2500 ĐỂ HOẠT ĐỘNG NHANH HƠN
  }

  function stopAutoMining() {
    autoMiningActive = false
    targetOreType = ''
    currentMiningTarget = null

    if (miningInterval) {
      clearInterval(miningInterval)
      miningInterval = null
    }

    bot.pathfinder.setGoal(null)
    bot.chat('⛏️ Dừng auto mine! Tớ nghỉ đào rồi~')
    console.log('⏹️ Auto Mining - Deactivated')
  }

  // ------------------ AUTO CHEST HUNTING ------------------
  async function startAutoChest() {
    // Dừng các hoạt động khác trước khi bắt đầu tìm rương
    stopFollowing()
    stopProtecting()
    if (autoFishingActive) stopAutoFishing()
    if (autoMiningActive) stopAutoMining()
    autoFarmActive = false

    autoChestActive = true
    currentChestTarget = null
    itemCollectionDisabled = false // Bật nhặt đồ khi tìm rương

    // Khởi tạo stats
    chestStats = {
      chestsFound: 0,
      startTime: Date.now(),
      explorationCount: 0
    }

    bot.chat('📦 Bắt đầu tìm rương! Phạm vi 50 blocks, tớ sẽ khám phá hang động!')
    console.log('📦 Auto Chest Hunting - Activated')

    if (chestInterval) clearInterval(chestInterval)
    chestHuntingLoop()
  }

  async function stopAutoChest() {
    if (!autoChestActive) return
    
    autoChestActive = false
    currentChestTarget = null

    if (chestInterval) {
      clearInterval(chestInterval)
      chestInterval = null
    }

    try {
      bot.pathfinder.setGoal(null)
    } catch (error) {
      console.log('⚠️ Lỗi dừng pathfinder:', error)
    }

    // Hiển thị thống kê
    if (chestStats.startTime !== 0) {
      const duration = ((Date.now() - chestStats.startTime) / 1000).toFixed(1)
      bot.chat(`📦 Dừng tìm rương! Tìm được ${chestStats.chestsFound} rương, khám phá ${chestStats.explorationCount} khu vực trong ${duration}s`)
      console.log(`📦 Chest Stats: Found ${chestStats.chestsFound}, Explored ${chestStats.explorationCount} areas in ${duration}s`)
    } else {
      bot.chat('📦 Dừng tìm rương!')
    }
    
    console.log('⏹️ Auto Chest Hunting - Deactivated')
  }

  // Hàm tìm chest với 2 mức quét (30 → 50 blocks)
  function findNearestChest() {
    // Quét 30 block trước (nhanh)
    let chest = bot.findBlock({
      matching: (block: any) => {
        if (!block || !block.name) return false
        const name = block.name.toLowerCase()
        return name.includes('chest') || name.includes('barrel') || name.includes('shulker')
      },
      maxDistance: 30,
      useExtraInfo: true
    })

    // Nếu không thấy, mở rộng ra 50 block
    if (!chest) {
      chest = bot.findBlock({
        matching: (block: any) => {
          if (!block || !block.name) return false
          const name = block.name.toLowerCase()
          return name.includes('chest') || name.includes('barrel') || name.includes('shulker')
        },
        maxDistance: 50,
        useExtraInfo: true
      })
    }

    return chest
  }

  // Khám phá hang động thông minh
  async function exploreCave() {
    const pos = bot.entity.position
    chestStats.explorationCount++

    // Tạo 3 hướng khám phá ngẫu nhiên và chọn hướng tốt nhất
    const directions = []
    for (let i = 0; i < 3; i++) {
      const dx = Math.floor(Math.random() * 9) - 4 // -4 to 4
      const dz = Math.floor(Math.random() * 9) - 4
      const dy = Math.floor(Math.random() * 3) - 1 // -1, 0, 1 (lên/xuống 1 block)
      
      directions.push({
        x: pos.x + dx,
        y: pos.y + dy,
        z: pos.z + dz,
        distance: Math.sqrt(dx*dx + dz*dz + dy*dy)
      })
    }

    // Chọn hướng gần vừa phải (không quá gần, không quá xa)
    const bestDirection = directions.sort((a, b) => 
      Math.abs(a.distance - 3) - Math.abs(b.distance - 3)
    )[0]

    const goal = new goals.GoalNear(bestDirection.x, bestDirection.y, bestDirection.z, 1)

    // Setup pathfinder cho khám phá hang
    const movements = new Movements(bot)
    movements.canDig = true // Cho phép đào block cản đường
    movements.allowSprinting = true
    movements.allowParkour = true
    movements.allow1by1towers = true
    movements.canOpenDoors = true
    movements.allowEntityDetection = true
    bot.pathfinder.setMovements(movements)

    bot.pathfinder.setGoal(goal)
    console.log(`🚶 Khám phá hang: di chuyển ${bestDirection.distance.toFixed(1)} blocks (lần ${chestStats.explorationCount})`)

    // Chờ bot di chuyển 4 giây
    await new Promise(resolve => setTimeout(resolve, 4000))

    // Dừng pathfinder để chuẩn bị cho lần tìm tiếp theo
    bot.pathfinder.setGoal(null)
  }

  // Vòng lặp tìm rương chính
  async function chestHuntingLoop() {
    if (!autoChestActive) return

    try {
      // 1. Kiểm tra kết nối bot
      if (!bot || !bot._client || bot._client.state !== 'play') {
        console.log('❌ Bot disconnected, stopping chest hunting')
        stopAutoChest()
        return
      }

      // 2. Kiểm tra túi đồ (dừng nếu quá đầy)
      const inventorySpaces = 36
      const usedSpaces = bot.inventory.items().length
      const freeSpaces = inventorySpaces - usedSpaces

      if (freeSpaces <= 2) {
        bot.chat('🎒 Túi đồ đầy! Dừng tìm rương!')
        stopAutoChest()
        return
      }

      // 3. Auto eat khi cần
      const health = bot.health
      const food = bot.food
      if ((health < 14 || food < 14) && !isEating) {
        await tryEatFood()
      }

      // 4. Kiểm tra mob gần và ưu tiên tiêu diệt
      const nearbyMob = bot.nearestEntity((entity: any) => {
        if (!entity || !entity.position) return false
        const distance = bot.entity.position.distanceTo(entity.position)
        if (distance > 8) return false

        const hostileMobs = [
          'zombie', 'skeleton', 'creeper', 'spider', 'witch', 'pillager', 'vindicator', 
          'evoker', 'husk', 'stray', 'phantom', 'drowned', 'enderman', 'breeze', 'bogged', 
          'slime', 'silverfish', 'cave_spider'
        ]
        const mobName = entity.name ? entity.name.toLowerCase() : ''
        const displayName = entity.displayName ? entity.displayName.toLowerCase() : ''

        const isHostile = hostileMobs.some(mobType => 
          mobName.includes(mobType) || displayName.includes(mobType)
        )

        const isMobType = entity.type === 'mob' && 
                         !mobName.includes('villager') && 
                         !mobName.includes('iron_golem')

        return isHostile || isMobType
      })

      // Nếu có mob gần, ưu tiên diệt mob trước
      if (nearbyMob && health > 8) {
        equipBestWeapon()
        const mobDistance = bot.entity.position.distanceTo(nearbyMob.position)
        
        if (mobDistance > 3) {
          const movements = new Movements(bot)
          movements.canDig = false
          movements.allowSprinting = true
          bot.pathfinder.setMovements(movements)
          bot.pathfinder.setGoal(new goals.GoalFollow(nearbyMob, 2))
        } else {
          bot.pathfinder.setGoal(null)
          // Tấn công spam
          for (let i = 0; i < 5; i++) {
            meleeAttack(nearbyMob, mobDistance)
          }
        }
        
        // Quay lại vòng lặp sau khi xử lý mob
        setTimeout(chestHuntingLoop, 2000)
        return
      }

      // 5. Tìm chest gần nhất
      const chestBlock = findNearestChest()

      if (chestBlock) {
        chestStats.chestsFound++
        currentChestTarget = chestBlock

        const distance = bot.entity.position.distanceTo(chestBlock.position)
        console.log(`📦 Tìm thấy ${chestBlock.name} tại ${chestBlock.position} - cách ${Math.round(distance)} blocks`)
        
        bot.chat(`📦 Phát hiện ${chestBlock.name} cách ${Math.round(distance)} blocks! Đang tiến đến...`)

        // Di chuyển đến cách rương 1 block
        const movements = new Movements(bot)
        movements.canDig = true // Có thể đào đường đến rương
        movements.allowSprinting = true
        movements.allowParkour = true
        movements.allow1by1towers = true
        movements.canOpenDoors = true
        bot.pathfinder.setMovements(movements)

        // Đến cách rương 1 block và dừng
        const goal = new goals.GoalNear(chestBlock.position.x, chestBlock.position.y, chestBlock.position.z, 1)
        bot.pathfinder.setGoal(goal)

        // Chờ bot di chuyển (thời gian tùy theo khoảng cách)
        const waitTime = Math.min(distance * 500, 10000) // Tối đa 10 giây
        await new Promise(resolve => setTimeout(resolve, waitTime))

        // Kiểm tra đã đến gần chest chưa
        const finalDistance = bot.entity.position.distanceTo(chestBlock.position)
        if (finalDistance <= 2) {
          bot.pathfinder.setGoal(null)
          bot.chat(`✅ Đã đến rương! Đứng cách ${Math.round(finalDistance)} block. Dừng tìm rương!`)
          console.log(`✅ Successfully reached chest at distance ${finalDistance.toFixed(2)}`)
          
          // Dừng auto chest khi đã tìm thấy và đến được rương
          stopAutoChest()
          return
        } else {
          console.log(`⚠️ Chưa đến được rương, khoảng cách: ${finalDistance.toFixed(2)}`)
          bot.chat('⚠️ Chưa đến được rương, tiếp tục tìm...')
        }

      } else {
        // Không tìm thấy chest, khám phá hang động
        console.log('🔍 Không tìm thấy chest trong 50 blocks, khám phá khu vực mới...')
        bot.chat('🔍 Không thấy rương, đang khám phá hang động...')
        
        await exploreCave()
      }

      // Thu thập items gần đây nếu có
      setTimeout(() => {
        if (!autoChestActive) return
        
        const entities = Object.values(bot.entities)
        for (const entity of entities) {
          if (entity.name === 'item' && entity.position && 
              bot.entity.position.distanceTo(entity.position) < 6) {
            bot.collectBlock.collect(entity).catch(() => {})
          }
        }
      }, 500)

    } catch (error: any) {
      console.log('❌ Lỗi chest hunting loop:', error.message || error)
      
      // Nếu lỗi nghiêm trọng thì dừng
      if (error?.code === 'EPIPE' || 
          error?.message?.includes('EPIPE') || 
          error?.message?.includes('disconnect')) {
        console.log('💔 Lỗi kết nối, dừng chest hunting')
        stopAutoChest()
        return
      }

      // Reset pathfinder nếu cần
      try {
        if (bot && bot._client && bot._client.state === 'play') {
          bot.pathfinder.setGoal(null)
        }
      } catch (e) {
        console.log('⚠️ Không thể reset pathfinder:', e)
        stopAutoChest()
        return
      }
    }

    // Tiếp tục vòng lặp nếu vẫn active
    if (autoChestActive) {
      setTimeout(chestHuntingLoop, 3000) // 3 giây mỗi lần check
    }
  }

  // ------------------ AUTO BUILD WITH AI ------------------
  let autoBuildActive = false
  let buildingBlueprint: any[] = []
  let buildPosition: any = null
  let currentBuildStep = 0

  async function generateBuildingBlueprint(structure: string): Promise<any[]> {
    if (!geminiApiKey) {
      bot.chat('🥺 Cần Gemini API key để tạo blueprint!')
      return []
    }

    try {
      bot.chat('🏗️ Đang tạo bản thiết kế với AI...')

      const prompt = `Tạo bản thiết kế Minecraft cho "${structure}" dưới dạng ma trận 3D.
Trả về JSON array với format:
[
  [
    ["block_name", "block_name", "block_name"],
    ["block_name", "air", "block_name"],
    ["block_name", "block_name", "block_name"]
  ]
]

Quy tắc:
- Mỗi layer là 1 tầng (Y level)
- "air" = không đặt block
- Dùng tên block Minecraft chính xác: stone, oak_wood, glass, etc.
- Kích thước tối đa 16x16x16
- Thiết kế đẹp và thực tế

Ví dụ nhà đơn giản:
[
  [
    ["cobblestone","cobblestone","cobblestone","cobblestone"],
    ["cobblestone","air","air","cobblestone"],
    ["cobblestone","air","air","cobblestone"],
    ["cobblestone","cobblestone","oak_door","cobblestone"]
  ],
  [
    ["oak_planks","glass","glass","oak_planks"],
    ["glass","air","air","glass"],
    ["glass","air","air","glass"],
    ["oak_planks","glass","glass","oak_planks"]
  ],
  [
    ["oak_planks","oak_planks","oak_planks","oak_planks"],
    ["oak_planks","oak_planks","oak_planks","oak_planks"],
    ["oak_planks","oak_planks","oak_planks","oak_planks"],
    ["oak_planks","oak_planks","oak_planks","oak_planks"]
  ]
]`

      const payload = {
        contents: [{
          parts: [{
            text: `Bạn là chuyên gia thiết kế Minecraft. Chỉ trả về JSON array theo format yêu cầu.\n\n${prompt}`
          }]
        }],
        generationConfig: {
          maxOutputTokens: 2000,
          temperature: 0.7
        }
      }

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const result = await response.json()

      if (!response.ok) {
        console.log('❌ API Error:', result)
        throw new Error(`API Error: ${result.error?.message || 'Unknown error'}`)
      }

      const blueprintText = result?.candidates?.[0]?.content?.parts?.[0]?.text

      if (blueprintText) {
        // Parse JSON từ response
        const jsonMatch = blueprintText.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          const blueprint = JSON.parse(jsonMatch[0])
          console.log('🏗️ Generated blueprint:', blueprint)
          return blueprint
        }
      }

      throw new Error('Không thể tạo blueprint')
    } catch (error) {
      console.log('❌ Lỗi tạo blueprint:', error)
      bot.chat('😵 Lỗi tạo blueprint! Thử lại sau~')
      return []
    }
  }

  async function prepareBuildMaterials() {
    if (!buildingBlueprint || buildingBlueprint.length === 0) return

    // Phân tích blueprint để tính materials cần thiết
    const materialsNeeded: { [key: string]: number } = {}

    for (let y = 0; y < buildingBlueprint.length; y++) {
      for (let x = 0; x < buildingBlueprint[y].length; x++) {
        for (let z = 0; z < buildingBlueprint[y][x].length; z++) {
          const blockName = buildingBlueprint[y][x][z]
          if (blockName && blockName !== 'air') {
            materialsNeeded[blockName] = (materialsNeeded[blockName] || 0) + 1
          }
        }
      }
    }

    console.log('📋 Materials needed:', materialsNeeded)

    // Danh sách các materials và give commands tương ứng - FIX: Dùng tên bot thay vì @s
    const materialCommands: { [key: string]: string } = {
      'cobblestone': `/give ${bot.username} cobblestone 64`,
      'stone': `/give ${bot.username} stone 64`, 
      'oak_planks': `/give ${bot.username} oak_planks 64`,
      'oak_wood': `/give ${bot.username} oak_log 64`,
      'glass': `/give ${bot.username} glass 64`,
      'brick': `/give ${bot.username} bricks 64`,
      'sandstone': `/give ${bot.username} sandstone 64`,
      'oak_door': `/give ${bot.username} oak_door 8`,
      'iron_door': `/give ${bot.username} iron_door 8`,
      'wool': `/give ${bot.username} white_wool 64`,
      'dirt': `/give ${bot.username} dirt 64`,
      'grass_block': `/give ${bot.username} grass_block 64`
    }

    // Lấy materials từ creative mode
    bot.chat('📦 Đang lấy vật liệu cần thiết...')

    for (const [material, amount] of Object.entries(materialsNeeded)) {
      // FIX: Dùng đúng tên bot thay vì @s
      const command = materialCommands[material] || materialCommands[material.replace('_', '')] || `/give ${bot.username} ${material} 64`

      // Tính số lần cần give (mỗi lần 64 blocks)
      const giveCount = Math.ceil(amount / 64)

      for (let i = 0; i < giveCount; i++) {
        bot.chat(command)
        await new Promise(resolve => setTimeout(resolve, 100)) // Delay ngắn giữa các commands
      }

      bot.chat(`✅ Đã lấy ${material}: ${amount} blocks`)
      await new Promise(resolve => setTimeout(resolve, 200))
    }

    bot.chat('🎒 Hoàn tất chuẩn bị vật liệu!')
  }

  async function startAutoBuild(structure: string) {
    if (autoBuildActive) {
      bot.chat('🏗️ Đang xây công trình khác rồi!')
      return
    }

    // Dừng các hoạt động khác
    stopFollowing()
    stopProtecting()
    if (autoFishingActive) stopAutoFishing()
    if (autoMiningActive) stopAutoMining()
    autoFarmActive = false

    autoBuildActive = true
    bot.chat(`🏗️ Bắt đầu auto xây "${structure}"!`)

    try {
      // Bước 1: Tạo blueprint với AI
      bot.chat('🤖 Đang thiết kế với AI...')
      buildingBlueprint = await generateBuildingBlueprint(structure)

      if (buildingBlueprint.length === 0) {
        autoBuildActive = false
        return
      }

      bot.chat(`✨ Thiết kế hoàn tất! Kích thước: ${buildingBlueprint[0].length}x${buildingBlueprint[0][0].length}x${buildingBlueprint.length}`)

      // Bước 2: Chuyển sang chế độ sáng tạo
      bot.chat('🎨 Chuyển sang chế độ sáng tạo...')
      bot.chat('/gamemode creative')
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Bước 3: Lấy materials cần thiết
      bot.chat('📦 Chuẩn bị vật liệu...')
      await prepareBuildMaterials()

      // Bước 4: Xây dựng
      buildPosition = {
        x: Math.floor(bot.entity.position.x),
        y: Math.floor(bot.entity.position.y),
        z: Math.floor(bot.entity.position.z)
      }

      bot.chat('🏗️ Bắt đầu xây dựng...')
      currentBuildStep = 0
      executeBuildStep()

    } catch (error) {
      console.log('❌ Lỗi auto build:', error)
      bot.chat('😵 Có lỗi xảy ra trong quá trình xây dựng!')
      autoBuildActive = false
    }
  }

  async function executeBuildStep() {
    if (!autoBuildActive || buildingBlueprint.length === 0) return

    const blueprint = buildingBlueprint
    const totalSteps = blueprint.length * blueprint[0].length * blueprint[0][0].length

    for (let y = 0; y < blueprint.length; y++) {
      const layer = blueprint[y]

      for (let x = 0; x < layer.length; x++) {
        const row = layer[x]

        for (let z = 0; z < row.length; z++) {
          const blockName = row[z]

          if (blockName === 'air' || !blockName) continue

          const buildPos = {
            x: buildPosition.x + x,
            y: buildPosition.y + y,
            z: buildPosition.z + z
          }

          try {
            // Di chuyển đến vị trí đặt block
            const goal = new goals.GoalNear(buildPos.x, buildPos.y, buildPos.z, 4)
            await bot.pathfinder.goto(goal)

            // Tìm block trong inventory
            let blockItem = bot.inventory.items().find(item => 
              item.name.includes(blockName) || 
              item.name === blockName ||
              item.name === blockName.replace('_', '')
            )

            // Nếu không có block, thử tìm block tương tự
            if (!blockItem) {
              const similarBlocks = {
                'cobblestone': ['stone', 'cobblestone'],
                'oak_planks': ['oak_planks', 'planks', 'wood'],
                'stone': ['stone', 'cobblestone'],
                'glass': ['glass'],
                'oak_wood': ['oak_log', 'log', 'wood'],
                'brick': ['bricks', 'brick'],
                'sandstone': ['sandstone']
              }

              const alternatives = similarBlocks[blockName] || [blockName]
              for (const alt of alternatives) {
                blockItem = bot.inventory.items().find(item => 
                  item.name.includes(alt)
                )
                if (blockItem) break
              }
            }

            if (!blockItem) {
              console.log(`⚠️ Không có block: ${blockName}, bỏ qua`)
              continue
            }

            // Trang bị block
            await bot.equip(blockItem, 'hand')

            // Đặt block
            const targetBlock = bot.blockAt(new Vec3(buildPos.x, buildPos.y - 1, buildPos.z))
            if (targetBlock) {
              await bot.placeBlock(targetBlock, new Vec3(0, 1, 0))
              console.log(`🧱 Đặt ${blockName} tại ${buildPos.x}, ${buildPos.y}, ${buildPos.z}`)
            }

            currentBuildStep++

            // Report progress mỗi 10 blocks
            if (currentBuildStep % 10 === 0) {
              const progress = Math.round((currentBuildStep / totalSteps) * 100)
              bot.chat(`🏗️ Tiến độ: ${progress}% (${currentBuildStep}/${totalSteps})`)
            }

            // Delay để không spam
            await new Promise(resolve => setTimeout(resolve, 200))

          } catch (error) {
            console.log(`❌ Lỗi đặt block ${blockName}:`, error)
          }

          // Kiểm tra nếu bị dừng
          if (!autoBuildActive) return
        }
      }
    }

    // Hoàn thành - Chuyển về survival mode
    autoBuildActive = false
    bot.chat('🎉 Hoàn thành xây dựng!')
    bot.chat('⚡ Chuyển về chế độ sinh tồn...')
    bot.chat('/gamemode survival')
    bot.chat('✅ Công trình đã sẵn sàng! Chúc cậu vui vẻ! 💕')
    console.log('✅ Auto build completed')
  }

  function stopAutoBuild() {
    autoBuildActive = false
    buildingBlueprint = []
    buildPosition = null
    currentBuildStep = 0
    bot.pathfinder.setGoal(null)
    bot.chat('🛑 Dừng auto xây!')
    console.log('⏹️ Auto Build - Deactivated')
  }

  // ------------------ Chat Commands ------------------
  bot.on('chat', async (username: string, message: string) => {
    console.log(`💬 Chat nhận được: [${username}]: ${message}`)

    if (username === bot.username || username === 'server' || username === 'console') {
      return
    }

    // Update last command time
    lastPlayerCommand = Date.now()

    const cleanMessage = message.toLowerCase().trim()
    console.log(`🔍 Xử lý lệnh: "${cleanMessage}" từ player: ${username}`)

    // Xử lý các lệnh chat
    if (cleanMessage.startsWith('auto xây ')) {
      // Lấy tên công trình từ lệnh
      const structure = message.substring(9).trim() // Lấy phần sau "auto xây "
      if (structure) {
        startAutoBuild(structure)
      } else {
        bot.chat('🤔 Cậu muốn tớ xây gì? VD: auto xây nhà, auto xây lâu đài')
      }
    } else if (cleanMessage.includes('dừng xây') || cleanMessage.includes('stop build')) {
      stopAutoBuild()
    } else if (cleanMessage.includes('theo')) {
      if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác

      // Kiểm tra xem có chỉ định player cụ thể không
      const followMatch = cleanMessage.match(/theo\s+(.+)/)
      if (followMatch && followMatch[1].trim() !== '' && !cleanMessage.startsWith('theo tớ')) {
        const targetName = followMatch[1].trim()
        startFollowingPlayer(targetName)
      } else {
        startFollowingPlayer(username)
      }
    } else if (cleanMessage.includes('bảo vệ')) {
      if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác

      // Kiểm tra xem có chỉ định player cụ thể không
      const protectMatch = cleanMessage.match(/bảo vệ\s+(.+)/)
      if (protectMatch && protectMatch[1].trim() !== '' && !cleanMessage.startsWith('bảo vệ tớ')) {
        const targetName = protectMatch[1].trim()
        startProtectingPlayer(targetName)
      } else {
        startProtectingPlayer(username)
      }
    // Bow commands removed
    } else if (cleanMessage.includes('dừng') || cleanMessage.includes('stop')) {
      stopAll()
    } else if (cleanMessage.includes('ngủ')) {
      if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác
      goSleep()
    } else if (cleanMessage.startsWith('cần')) {
      giveItemToPlayer(username, message)
    } else if (cleanMessage.includes('cất đồ')) {
      if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác
      storeItemsInChest()
    } else if (cleanMessage.includes('auto farm all') || cleanMessage.includes('farm')) {
      if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác
      startAutoFarmAll()
    } else if (cleanMessage.startsWith('tớ hỏi nè')) {
      handleQuestionWithAI(username, message)
    } else if (cleanMessage.includes('auto câu') || cleanMessage.includes('fishing')) {
      startSmartAutoFishing()
    } else if (cleanMessage.includes('dừng câu') || cleanMessage.includes('stop fishing')) {
      stopSmartAutoFishing()
    } else if (cleanMessage.startsWith('auto mine ')) {
      // Lấy tên quặng từ lệnh
      const oreType = message.substring(10).trim() // Lấy phần sau "auto mine "
      if (oreType) {
        if (autoFishingActive) stopAutoFishing() // Dừng câu khi có lệnh khác
        startAutoMining(oreType)
      } else {
        bot.chat('🤔 Cậu muốn tớ đào gì? VD: auto mine coal, auto mine diamond')
      }
    } else if (cleanMessage.includes('dừng mine') || cleanMessage.includes('stop mine')) {
      stopAutoMining()
    } else if (cleanMessage.includes('auto tìm rương') || cleanMessage.includes('auto chest')) {
      startAutoChest()
    } else if (cleanMessage.includes('dừng tìm rương') || cleanMessage.includes('dừng chest') || cleanMessage.includes('stop chest')) {
      stopAutoChest()
    } else if (cleanMessage.startsWith('hãy nói ')) {
      // Chức năng lặp lại câu nói
      const textToRepeat = message.substring(8).trim() // Lấy phần sau "hãy nói "
      if (textToRepeat) {
        bot.chat(textToRepeat)
        console.log(`🔊 Bot lặp lại: "${textToRepeat}"`)
      } else {
        bot.chat('🤔 Cậu muốn tớ nói gì?')
      }
    } else if (cleanMessage.includes('spam attack') || cleanMessage.includes('tấn công spam')) {
      // Kích hoạt chế độ spam attack đặc biệt
      bot.chat('🔥 SPAM ATTACK MODE ON! Tớ sẽ đánh cực nhanh không delay!')
      console.log('🔥 Spam Attack Mode: ACTIVATED')

      // Tìm và spam attack mob gần nhất
      const nearestMob = bot.nearestEntity((entity: any) => {
        if (!entity || !entity.position) return false
        const distance = bot.entity.position.distanceTo(entity.position)
        if (distance > 10) return false

        const hostileMobs = [
          'zombie', 'skeleton', 'creeper', 'spider', 'witch', 'pillager', 'vindicator', 
          'evoker', 'husk', 'stray', 'phantom', 'drowned', 'enderman', 'breeze', 'bogged', 
          'slime', 'silverfish', 'cave_spider'
        ]
        const mobName = entity.name ? entity.name.toLowerCase() : ''
        const displayName = entity.displayName ? entity.displayName.toLowerCase() : ''

        const isHostile = hostileMobs.some(mobType => 
          mobName.includes(mobType) || displayName.includes(mobType)
        )

        const isMobType = entity.type === 'mob' && 
                         !mobName.includes('villager') && 
                         !mobName.includes('iron_golem')

        return isHostile || isMobType
      })

      if (nearestMob) {
        equipBestWeapon()
        bot.setControlState('sprint', true)

        // ULTRA MEGA SPAM - 20 lần tấn công liên tiếp
        for (let megaSpam = 0; megaSpam < 20; megaSpam++) {
          meleeAttack(nearestMob, bot.entity.position.distanceTo(nearestMob.position))
        }
        bot.chat('⚔️ MEGA SPAM COMPLETE! 20x attacks delivered!')
      } else {
        bot.chat('🤔 Không thấy mob nào để spam attack!')
      }
    }
  })

  // ------------------ Question AI Response ------------------
  async function handleQuestionWithAI(username: string, message: string) {
    if (!geminiApiKey) {
      bot.chat('🥺 Tớ chưa được cấu hình Gemini AI, cậu liên hệ admin nhé!')
      return
    }

    try {
      // Hiển thị tin nhắn đang suy nghĩ
      bot.chat('💭 Để tớ suy nghĩ cute cute nè~ (◕‿◕)✨')

      const question = message.replace(/tớ hỏi nè/i, '').trim()
      const systemPrompt = `Bạn là bot Minecraft tên Loli, rất đáng yêu và kawaii! ${username} hỏi: "${question}". 

Hãy trả lời câu hỏi này với phong cách:
- Dùng nhiều emoji cute: 💕 🌸 ✨ (◕‿◕) >.<  uwu (´∀｀) ♡ 💖 🎀 
- Xưng tớ, gọi cậu 
- Phong cách loli kawaii, ngọt ngào
- Dưới 100 ký tự
- Thêm từ cute như "nè", "mà", "uwu", "kyaa"
- Hữu ích nhưng rất đáng yêu`

      const payload = {
        contents: [{
          parts: [{
            text: `${systemPrompt}\n\nCâu hỏi: ${question}`
          }]
        }],
        generationConfig: {
          maxOutputTokens: 120,
          temperature: 0.9
        }
      }

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const result = await response.json()

      if (!response.ok) {
        console.log('❌ AI API Error:', result)
        throw new Error(`API Error: ${result.error?.message || 'Unknown error'}`)
      }

      const generatedText = result?.candidates?.[0]?.content?.parts?.[0]?.text

      if (generatedText && generatedText.trim() !== '') {
        // Chỉ trả lời khi có nội dung thật từ AI
        bot.chat(generatedText.substring(0, 100))
      } else {
        // Trả lời đơn giản khi AI không có câu trả lời
        bot.chat(`🥺 Tớ không biết câu trả lời này, cậu hỏi câu khác nhé! (◕‿◕)💕`)
      }
    } catch (error) {
      // Trả lời đơn giản khi có lỗi AI
      bot.chat('🥺 Tớ bị lỗi rồi, cậu hỏi lại sau nhé!')
      console.error('Lỗi chat AI:', error)
    }
  }

  // ------------------ Follow / Protect ------------------
  function startFollowingPlayer(username: string) {
    // Tìm player entity với nhiều cách khác nhau
    let playerEntity = bot.players[username]?.entity

    // Nếu không tìm thấy, thử tìm theo tên không có dấu chấm
    if (!playerEntity && username.startsWith('.')) {
      const nameWithoutDot = username.substring(1)
      playerEntity = bot.players[nameWithoutDot]?.entity
    }

    // Nếu vẫn không tìm thấy, thử tìm theo tên có dấu chấm
    if (!playerEntity && !username.startsWith('.')) {
      const nameWithDot = '.' + username
      playerEntity = bot.players[nameWithDot]?.entity
    }

    // Tìm trong tất cả players nếu vẫn không thấy
    if (!playerEntity) {
      const allPlayers = Object.keys(bot.players)
      console.log(`🔍 Tìm kiếm player: ${username} trong danh sách:`, allPlayers)

      // Tìm player gần đúng
      for (const playerName of allPlayers) {
        if (playerName.toLowerCase().includes(username.toLowerCase()) || 
            username.toLowerCase().includes(playerName.toLowerCase())) {
          playerEntity = bot.players[playerName]?.entity
          console.log(`✅ Tìm thấy player tương ứng: ${playerName}`)
          break
        }
      }
    }

    if (!playerEntity) {
      bot.chat(`🥺 Cậu phải ở trong tầm nhìn của tớ thì tớ mới đi theo được!!?`)
      console.log(`❌ Không tìm thấy player: ${username}`)
      return
    }

    targetPlayer = playerEntity
    bot.chat(`❤️ Tớ sẽ theo cậu đến cùng trời cuối đất!`)
    stopProtecting()
    itemCollectionDisabled = false // Bật lại nhặt đồ khi dùng chức năng
    startFollowing()
    console.log(`✅ Bắt đầu theo ${username}`)
  }

  function startFollowing() {
    isFollowing = true
    if (followInterval) clearInterval(followInterval)

    let tpFailCount = 0 // Đếm số lần /tp thất bại
    let lastBoatCheck = 0 // Track lần cuối kiểm tra thuyền
    let isInBoat = false // Track trạng thái đang ngồi thuyền

    followInterval = setInterval(async () => {
      if (!targetPlayer || !targetPlayer.isValid) {
        stopFollowing()
        return
      }

      const targetPos = targetPlayer.position
      const distance = bot.entity.position.distanceTo(targetPos)
      const currentTime = Date.now()

      // KIỂM TRA THUYỀN MỖI 5 GIÂY
      if (currentTime - lastBoatCheck > 5000) {
        lastBoatCheck = currentTime

        // Tìm thuyền gần trong bán kính 4 blocks
        const nearbyBoat = bot.nearestEntity((entity: any) => {
          if (!entity || !entity.position) return false
          const boatDistance = bot.entity.position.distanceTo(entity.position)
          return boatDistance <= 4 && entity.name && entity.name.includes('boat')
        })

        if (nearbyBoat && !isInBoat) {
          // Có thuyền gần và chưa ngồi thuyền
          console.log(`🛥️ Tìm thấy thuyền ${nearbyBoat.name} cách ${Math.round(bot.entity.position.distanceTo(nearbyBoat.position))} blocks`)

          try {
            // Di chuyển đến thuyền và ngồi lên
            await bot.pathfinder.goto(new goals.GoalBlock(nearbyBoat.position.x, nearbyBoat.position.y, nearbyBoat.position.z))
            bot.mount(nearbyBoat)
            isInBoat = true
            console.log('🛥️ Đã lên thuyền!')
            bot.chat('🛥️ Lên thuyền theo cậu rồi!')
          } catch (error) {
            console.log('❌ Không thể lên thuyền:', error)
          }
        } else if (isInBoat && distance > 4) {
          // Đang ngồi thuyền nhưng cách player quá 4 blocks - xuống thuyền
          console.log(`🛥️ Cách player xa ${Math.round(distance)} blocks, xuống thuyền`)

          try {
            bot.dismount()
            isInBoat = false
            console.log('🛥️ Đã xuống thuyền!')
            bot.chat('🛥️ Xuống thuyền để theo cậu gần hơn!')
          } catch (error) {
            console.log('❌ Không thể xuống thuyền:', error)
            isInBoat = false // Reset trạng thái
          }
        }
      }

      // Nếu đang ngồi thuyền và gần player thì không cần làm gì thêm
      if (isInBoat && distance <= 4) {
        return
      }

      // Nếu quá xa thì teleport
      if (distance > 15) {
        try {
          // Kiểm tra nếu đã thất bại quá nhiều lần
          if (tpFailCount >= 3) {
            bot.chat('🥺 Tớ không có quyền dùng /tp để theo cậu. Tớ sẽ dừng theo dõi!')
            stopFollowing()
            return
          }

          bot.chat(`/tp ${bot.username} ${targetPlayer.username}`)

          // Kiểm tra thành công sau 2 giây
          setTimeout(() => {
            const newDistance = bot.entity.position.distanceTo(targetPlayer.position)
            if (newDistance > 12) { // Nếu vẫn xa thì /tp thất bại
              tpFailCount++
              console.log(`⚠️ /tp thất bại lần ${tpFailCount}/3`)

              if (tpFailCount >= 3) {
                bot.chat('🥺 Tớ không có quyền dùng /tp. Dừng theo dõi!')
                stopFollowing()
              }
            } else {
              tpFailCount = 0 // Reset nếu thành công
            }
          }, 2000)

        } catch (e) {
          tpFailCount++
          // Nếu không thể tp, thì đào đường và di chuyển
          if (tpFailCount < 3) {
            bot.pathfinder.setGoal(new goals.GoalBlock(targetPos.x, targetPos.y, targetPos.z))

            // Cho phép đập mọi khối cản
            const movements = new Movements(bot)
            movements.canDig = true
            movements.allow1by1towers = true
            movements.allowParkour = true
            movements.allowSprinting = true
            movements.allowEntityDetection = true
            movements.allowFreeMotion = true
            movements.canOpenDoors = true

            bot.pathfinder.setMovements(movements)
          } else {
            bot.chat('🥺 Tớ không thể đến gần cậu! Dừng theo dõi!')
            stopFollowing()
          }
        }
        return
      }

      // Reset count khi ở gần
      if (distance <= 10) {
        tpFailCount = 0
      }

      // Chỉ di chuyển theo khi không ngồi thuyền
      if (!isInBoat) {
        try {
          bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
        } catch (error) {
          console.log('Lỗi follow:', error)
        }
      }
    }, 2000)
  }

  function stopFollowing() {
    isFollowing = false
    if (followInterval) {
      clearInterval(followInterval)
      followInterval = null
    }
    bot.pathfinder.setGoal(null)
  }

  function startProtectingPlayer(username: string) {
    // Tìm player entity với nhiều cách khác nhau
    let playerEntity = bot.players[username]?.entity

    // Nếu không tìm thấy, thử tìm theo tên không có dấu chấm
    if (!playerEntity && username.startsWith('.')) {
      const nameWithoutDot = username.substring(1)
      playerEntity = bot.players[nameWithoutDot]?.entity
    }

    // Nếu vẫn không tìm thấy, thử tìm theo tên có dấu chấm
    if (!playerEntity && !username.startsWith('.')) {
      const nameWithDot = '.' + username
      playerEntity = bot.players[nameWithDot]?.entity
    }

    // Tìm trong tất cả players nếu vẫn không thấy
    if (!playerEntity) {
      const allPlayers = Object.keys(bot.players)
      console.log(`🔍 Tìm kiếm player: ${username} trong danh sách:`, allPlayers)

      // Tìm player gần đúng
      for (const playerName of allPlayers) {
        if (playerName.toLowerCase().includes(username.toLowerCase()) || 
            username.toLowerCase().includes(playerName.toLowerCase())) {
          playerEntity = bot.players[playerName]?.entity
          console.log(`✅ Tìm thấy player tương ứng: ${playerName}`)
          break
        }
      }
    }

    if (!playerEntity) {
      bot.chat(`🥺 Cậu phải ở gần tớ thì tớ mới bảo vệ được!?💞`)
      console.log(`❌ Không tìm thấy player: ${username}`)
      return
    }

    targetPlayer = playerEntity
    bot.chat(`🛡️ Tớ sẽ bảo vệ cậu khỏi tất cả nguy hiểm!`)
    stopFollowing()
    itemCollectionDisabled = false // Bật lại nhặt đồ khi dùng chức năng
    startProtecting()
    console.log(`✅ Bắt đầu bảo vệ ${username}`)
  }

  // Biến kiểm tra quyền OP
  let hasOpPermission: boolean | null = null
  let hasTriedOpCommand = false
  let lastOpCheckTime = 0

  function startProtecting() {
    isProtecting = true
    if (protectInterval) clearInterval(protectInterval)

    // Reset OP check khi bắt đầu bảo vệ mới
    hasOpPermission = null
    hasTriedOpCommand = false
    lastOpCheckTime = 0

    protectInterval = setInterval(async () => {
      if (!targetPlayer || !targetPlayer.isValid) {
        stopProtecting()
        return
      }

      const targetPos = targetPlayer.position
      const distanceToPlayer = bot.entity.position.distanceTo(targetPos)
      const health = bot.health
      const protectTime = Date.now()
      
      // Auto buff khi máu yếu
      if (health < 8 && (protectTime - lastOpCheckTime) > 10000) { // Kiểm tra mỗi 10 giây
        lastOpCheckTime = protectTime

        if (hasOpPermission === null && !hasTriedOpCommand) {
          hasTriedOpCommand = true
          bot.chat(`/effect give ${bot.username} regeneration 5 100 true`)
          setTimeout(() => bot.chat('Đòi ăn ai'), 100)

          setTimeout(() => {
            if (bot.health > health) {
              hasOpPermission = true
              console.log('✅ Bot có quyền OP - có thể sử dụng effects')
            } else {
              hasOpPermission = false
              bot.chat('🥺 Tớ không có quyền OP để tự buff, nhưng vẫn bảo vệ cậu!')
              console.log('❌ Bot không có quyền OP')
            }
          }, 3000)

        } else if (hasOpPermission === true) {
          // PROTECT: LOẠI BỎ speed và resistance - chỉ dùng regeneration và strength
          bot.chat(`/effect give ${bot.username} regeneration 5 100 true`)
          setTimeout(() => bot.chat(`/effect give ${bot.username} strength 5 2 true`), 100)
          setTimeout(() => bot.chat('Đòi ăn ai'), 200)
          console.log('💪 Bot đã tự buff khi máu yếu!')
        }
      }

      // Tìm quái gần nhất trong phạm vi rộng hơn để có thể tiến tới tấn công
      let mob = bot.nearestEntity((entity: any) => {
        if (!entity || !entity.position) return false

        const distanceToMob = bot.entity.position.distanceTo(entity.position)
        if (distanceToMob > 20) return false // Phạm vi tìm quái 20 blocks

        // Các loại mob cần tấn công
        const hostileMobs = [
          'zombie', 'skeleton', 'creeper', 'spider', 'witch', 'pillager', 'vindicator', 'evoker', 
          'husk', 'stray', 'phantom', 'drowned', 'xtray', 'enderman', 'breeze', 'bogged', 
          'slime', 'silverfish', 'cave_spider', 'sulked'
        ]
        const mobName = entity.name ? entity.name.toLowerCase() : ''
        const displayName = entity.displayName ? entity.displayName.toLowerCase() : ''

        // Kiểm tra theo tên hoặc displayName
        const isHostile = hostileMobs.some(mobType => 
          mobName.includes(mobType) || displayName.includes(mobType)
        )

        // Hoặc kiểm tra theo type
        const isMobType = entity.type === 'mob' && 
                         !mobName.includes('villager') && 
                         !mobName.includes('iron_golem')

        return isHostile || isMobType
      })

      // LOGIC BẢO VỆ CẢI THIỆN: CHO PHÉP BOT TIẾN ĐẾN TẤN CÔNG NHƯNG BẮT BUỘC QUAY VỀ KHI CÁCH >10 BLOCKS
      if (distanceToPlayer > 15) {
        // CÁCH PLAYER >15 BLOCKS: THỬ TELEPORT TRƯỚC
        try {
          bot.chat(`/tp ${bot.username} ${targetPlayer.username}`)
          console.log(`🚀 Teleport về player vì cách ${Math.round(distanceToPlayer)} blocks`)
          bot.pvp.stop()
          
          // Kiểm tra thành công sau 2 giây
          setTimeout(() => {
            const newDistance = bot.entity.position.distanceTo(targetPlayer.position)
            if (newDistance > 12) {
              // Teleport thất bại, di chuyển thường
              console.log('⚠️ Teleport thất bại, di chuyển thường')
              bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 3), true)
              bot.setControlState('sprint', true)
            }
          }, 2000)
        } catch (e) {
          // Không thể teleport, di chuyển thường
          bot.pvp.stop()
          bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 3), true)
          bot.setControlState('sprint', true)
        }
      } else if (mob && health > 6 && !isEating) { 
        // CÓ QUÁI VÀ ĐỦ MÁU: CHO PHÉP TẤN CÔNG
        const mobDistance = bot.entity.position.distanceTo(mob.position)

        // Tự động trang bị vũ khí cận chiến
        if (!bot.heldItem || bot.heldItem.name.includes('bow')) {
          equipBestWeapon()
        }

        // KIỂM TRA KHOẢNG CÁCH ĐẾN PLAYER TRONG QUÁ TRÌNH TẤN CÔNG
        if (distanceToPlayer > 10) {
          // NẾU ĐANG TẤN CÔNG NHƯNG ĐÃ CÁCH PLAYER QUÁ 10 BLOCKS: BẮT BUỘC QUAY VỀ
          bot.pvp.stop()
          bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 3), true)
          bot.setControlState('sprint', true)
          console.log(`🛡️ Đang tấn công nhưng cách player ${Math.round(distanceToPlayer)}m > 10 blocks, bắt buộc quay về!`)
        } else if (mobDistance > 4) {
          // ĐỦ GẦN PLAYER VÀ CÓ QUÁI: TIẾN ĐẾN QUÁI ĐỂ TẤN CÔNG
          // Kiểm tra xem có an toàn để tiến đến mob không (tức là không sẽ làm bot cách player >10 blocks)
          const mobPos = mob.position
          const futureDistanceToPlayer = targetPlayer.position.distanceTo(mobPos)
          
          if (futureDistanceToPlayer <= 8) { 
            // An toàn để tiến đến mob - không làm bot cách player quá xa
            bot.pathfinder.setGoal(new goals.GoalFollow(mob, 2))
            bot.setControlState('sprint', true)
            console.log(`⚔️ Tiến đến tấn công ${mob.name} (cách mob ${Math.round(mobDistance)}m, sẽ cách player ${Math.round(futureDistanceToPlayer)}m)`)
          } else {
            // Mob quá xa so với player, ưu tiên bảo vệ player
            bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 3), true)
            bot.setControlState('sprint', true)
            console.log(`🛡️ Mob xa player, ưu tiên bảo vệ (mob cách player ${Math.round(futureDistanceToPlayer)}m)`)
          }
        } else {
          // ĐỦ GẦN ĐỂ TẤN CÔNG TRỰC TIẾP - SPAM ATTACK
          bot.pathfinder.setGoal(null)
          bot.setControlState('sprint', true)

          if (mob && mob.isValid) {
            for (let megaSpam = 0; megaSpam < 5; megaSpam++) {
              meleeAttack(mob, mobDistance)
            }
            console.log(`⚔️ Tấn công trực tiếp ${mob.name} (cách ${Math.round(mobDistance)}m)`)
          }
        }
      } else if (health <= 6) {
        // MÁU YẾU: Dừng tấn công và ưu tiên về gần player
        bot.pvp.stop()
        bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
        console.log(`💔 Máu yếu (${health}/20), quay về player an toàn`)
      } else if (distanceToPlayer > 4) {
        // KHÔNG CÓ QUÁI VÀ XA PLAYER: Di chuyển về gần player
        bot.pvp.stop()
        bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
        console.log(`🛡️ Không có quái, di chuyển về gần player (cách ${Math.round(distanceToPlayer)}m)`)
      } else {
        // KHÔNG CÓ QUÁI VÀ GẦN PLAYER: Giữ khoảng cách an toàn và sẵn sàng
        bot.pvp.stop()
        bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
      }
    }, 600) // Tăng interval để giảm spam và lag
  }

  function stopProtecting() {
    isProtecting = false
    if (protectInterval) {
      clearInterval(protectInterval)
      protectInterval = null
    }
    bot.pvp.stop()
    bot.pathfinder.setGoal(null)
  }

  // Hàm equipBestWeapon đã được định nghĩa ở trên

  function stopAll() {
    stopFollowing()
    stopProtecting()
    if (autoFishingActive) stopAutoFishing()
    if (autoBuildActive) stopAutoBuild()
    if (autoMiningActive) stopAutoMining()
    if (autoChestActive) stopAutoChest()
    targetPlayer = null
    autoFarmActive = false
    autoChestHuntActive = false
    autoFishingActive = false
    autoMiningActive = false
    autoChestActive = false
    itemCollectionDisabled = true // Tắt nhặt đồ khi dừng

    if (bot && bot._client && bot._client.state === 'play') {
      bot.chat(`🛑 Được rồi cậu, tớ dừng tất cả hoạt động đây! 💕`)
    }
    console.log('⏹️ Dừng tất cả hoạt động (bao gồm nhặt đồ, auto build, auto mining và auto chest)')
  }

  // ------------------ Sleep ------------------
  async function goSleep() {
    console.log('😴 Yêu cầu bot đi ngủ')

    if (bot.time.isDay) {
      bot.chat(`☀️ Trời đang sáng mà cậu, chưa đi ngủ được đâu!`)
      return
    }

    const bedBlock = bot.findBlock({
      matching: (block: any) => block.name.includes('bed'),
      maxDistance: 16
    })

    if (bedBlock) {
      bot.chat(`😴 Tớ buồn ngủ quá, đi ngủ thôi nào!`)
      try {
        await bot.sleep(bedBlock)
        bot.chat(`Zzz... 😴`)
      } catch (err) {
        bot.chat(`😢 Tớ không ngủ được ở đây. Cậu tìm chỗ khác nhé.`)
        console.log('Lỗi ngủ:', err)
      }
    } else {
      bot.chat(`🛌 Tớ không tìm thấy giường nào gần đây cả.`)
    }
  }

  // ------------------ Give Item ------------------
  function giveItemToPlayer(username: string, msg: string) {
    const match = msg.match(/cần (\d+) (\w+)/)
    if (!match) return

    const qty = parseInt(match[1])
    const name = match[2]

    // Tìm player entity với nhiều cách khác nhau
    let playerEntity = bot.players[username]?.entity

    // Nếu không tìm thấy, thử tìm theo tên không có dấu chấm
    if (!playerEntity && username.startsWith('.')) {
      const nameWithoutDot = username.substring(1)
      playerEntity = bot.players[nameWithoutDot]?.entity
    }

    // Nếu vẫn không tìm thấy, thử tìm theo tên có dấu chấm
    if (!playerEntity && !username.startsWith('.')) {
      const nameWithDot = '.' + username
      playerEntity = bot.players[nameWithDot]?.entity
    }

    // Tìm trong tất cả players nếu vẫn không thấy
    if (!playerEntity) {
      const allPlayers = Object.keys(bot.players)
      for (const playerName of allPlayers) {
        if (playerName.toLowerCase().includes(username.toLowerCase()) || 
            username.toLowerCase().includes(playerName.toLowerCase())) {
          playerEntity = bot.players[playerName]?.entity
          break
        }
      }
    }

    if (!playerEntity) {
      bot.chat(`🥺 Không thấy cậu để đưa ${name}`)
      return
    }

    const item = bot.inventory.items().find(i => i.name.includes(name))
    if (!item) {
      bot.chat(`🥺 Không có ${name}`)
      return
    }

    const throwItem = async () => {
      try {
        const distance = bot.entity.position.distanceTo(playerEntity.position)
        if (distance > 3) {
          bot.pathfinder.setGoal(new goals.GoalFollow(playerEntity, 2))
        } else {
          await bot.toss(item.type, null, qty)
          bot.chat(`🎁 Đã ném ${item.name} cho ${username}`)
        }
      } catch (error) {
        console.log('Lỗi ném item:', error)
      }
    }

    throwItem()
  }





  // ------------------ Cất đồ vào rương ------------------
  async function storeItemsInChest() {
    try {
      bot.chat('📦 Tớ sẽ cất TẤT CẢ đồ vào rương và sắp xếp theo ưu tiên!')

      // Tìm rương gần nhất
      const chestBlock = bot.findBlock({
        matching: (block: any) => {
          return block.name.includes('chest') || 
                 block.name.includes('barrel') ||
                 block.name.includes('shulker')
        },
        maxDistance: 32
      })

      if (!chestBlock) {
        bot.chat('🥺 Tớ không tìm thấy rương nào gần để cất đồ...')
        return
      }

      // Di chuyển đến rương
      const goal = new goals.GoalNear(chestBlock.position.x, chestBlock.position.y, chestBlock.position.z, 1)
      await bot.pathfinder.goto(goal)

      // Mở rương và cất đồ
      await bot.lookAt(chestBlock.position, true)
      const chest = await bot.openChest(chestBlock)

      // Phân loại đồ theo ưu tiên: khoáng sản > thức ăn > block > linh tinh
      const categorizedItems = {
        minerals: [] as any[],
        food: [] as any[],
        blocks: [] as any[],
        misc: [] as any[]
      }

      // Danh sách khoáng sản
      const minerals = ['diamond', 'emerald', 'gold', 'iron', 'coal', 'redstone', 'lapis', 'quartz', 'netherite', 'copper', 'amethyst']
      // Danh sách thức ăn
      const foods = ['bread', 'apple', 'meat', 'fish', 'potato', 'carrot', 'beef', 'pork', 'chicken', 'mutton', 'salmon', 'cod', 'golden_apple', 'enchanted_golden_apple', 'cookie', 'cake', 'pie', 'soup', 'stew']
      // Danh sách block
      const blocks = ['stone', 'dirt', 'grass', 'wood', 'log', 'plank', 'cobblestone', 'sand', 'gravel', 'glass', 'wool', 'brick', 'concrete', 'terracotta']

      // Phân loại items
      for (const item of bot.inventory.items()) {
        const itemName = item.name.toLowerCase()

        if (minerals.some(mineral => itemName.includes(mineral))) {
          categorizedItems.minerals.push(item)
        } else if (foods.some(food => itemName.includes(food))) {
          categorizedItems.food.push(item)
        } else if (blocks.some(block => itemName.includes(block))) {
          categorizedItems.blocks.push(item)
        } else {
          categorizedItems.misc.push(item)
        }
      }

      let storedCount = 0

      // Cất theo thứ tự ưu tiên
      const storeCategory = async (items: any[], categoryName: string) => {
        for (const item of items) {
          try {
            await chest.deposit(item.type, null, item.count)
            storedCount++
            console.log(`📦 Cất ${categoryName}: ${item.name} x${item.count}`)
            await new Promise(resolve => setTimeout(resolve, 100))
          } catch (error) {
            console.log(`Lỗi cất ${categoryName}:`, error)
          }
        }
      }

      // Cất theo thứ tự ưu tiên
      await storeCategory(categorizedItems.minerals, 'khoáng sản')
      await storeCategory(categorizedItems.food, 'thức ăn')
      await storeCategory(categorizedItems.blocks, 'block')
      await storeCategory(categorizedItems.misc, 'linh tinh')

      chest.close()

      bot.chat(`✅ Đã cất TẤT CẢ ${storedCount} items theo ưu tiên:`)
      bot.chat(`💎 Khoáng sản: ${categorizedItems.minerals.length}`)
      bot.chat(`🍞 Thức ăn: ${categorizedItems.food.length}`)
      bot.chat(`🧱 Block: ${categorizedItems.blocks.length}`)
      bot.chat(`📦 Linh tinh: ${categorizedItems.misc.length}`)

    } catch (error) {
      bot.chat('🥺 Có lỗi khi cất đồ...')
      console.log('Lỗi store items:', error)
    }
  }

  // ------------------ Auto Farm All ------------------
  function startAutoFarmAll() {
    autoFarmActive = true
    itemCollectionDisabled = false // Bật lại nhặt đồ khi farm

    // Reset OP check cho farm mode
    hasOpPermission = null
    hasTriedOpCommand = false
    lastOpCheckTime = 0

    bot.chat('🗡️ Bắt đầu farm tất cả mob')

    const farmInterval = setInterval(async () => {
      if (!autoFarmActive) {
        clearInterval(farmInterval)
        return
      }

      try {
        // Trang bị vũ khí tốt nhất
        equipBestWeapon()

        // Bow code removed

        // TÌM MOB GẦN NHẤT TRƯỚC TIÊN - ưu tiên gần nhất
        let mob = bot.nearestEntity((entity: any) => {
          if (!entity || !entity.position) return false

          const distance = bot.entity.position.distanceTo(entity.position)
          if (distance > 25) return false // Phạm vi tìm kiếm tối đa 25 blocks

          // Các loại mob cần farm - UPDATED LIST (loại bỏ 'horse')
          const farmableMobs = [
            'zombie', 'skeleton', 'creeper', 'spider', 'witch', 'slime',
            'cow', 'pig', 'chicken', 'sheep', 'rabbit', // Loại bỏ 'horse'
            'zombie_villager', 'husk', 'stray', 'phantom', 'drowned',
            'pillager', 'vindicator', 'evoker', 'ravager', 'enderman', 'xtray', 'sulked',
            'breeze', 'bogged', 'silverfish', 'cave_spider'
          ]

          const mobName = entity.name ? entity.name.toLowerCase() : ''
          const displayName = entity.displayName ? entity.displayName.toLowerCase() : ''

          // Loại trừ các mob không nên farm
          if (mobName.includes('villager') || 
              mobName.includes('iron_golem') ||
              mobName.includes('wolf') ||
              mobName.includes('horse') ||
              entity.username) {
            return false
          }

          // Kiểm tra theo tên
          const isFarmable = farmableMobs.some(mobType => 
            mobName.includes(mobType) || displayName.includes(mobType)
          )

          // Hoặc kiểm tra theo type
          const isMobType = entity.type === 'mob'

          return isFarmable || isMobType
        })

        // Kiểm tra máu và sử dụng effect nếu cần (tương tự như protect mode)
        const health = bot.health
        const autoFarmTime = Date.now()
        if (health < 8 && (autoFarmTime - lastOpCheckTime) > 10000) {
          lastOpCheckTime = autoFarmTime

          if (hasOpPermission === null && !hasTriedOpCommand) {
            hasTriedOpCommand = true
            bot.chat(`/effect give ${bot.username} regeneration 5 100 true`)
            setTimeout(() => bot.chat('Đòi ăn ai'), 100)

            setTimeout(() => {
              if (bot.health > health) {
                hasOpPermission = true
                console.log('✅ Farm mode: Bot có quyền OP')
              } else {
                hasOpPermission = false
                console.log('❌ Farm mode: Bot không có quyền OP')
              }
            }, 3000)

          } else if (hasOpPermission === true) {
            // AUTO FARM: LOẠI BỎ speed và resistance - chỉ dùng regeneration và strength
            bot.chat(`/effect give ${bot.username} regeneration 5 100 true`)
            setTimeout(() => bot.chat(`/effect give ${bot.username} strength 5 2 true`), 100)
            setTimeout(() => bot.chat('Đòi ăn ai'), 200)
            console.log('💪 Auto farm: Bot đã tự buff!')
          }
        }

        if (mob) {
          console.log(`🗡️ Tấn công ${mob.name || mob.displayName} (${Math.round(bot.entity.position.distanceTo(mob.position))} blocks)`)

          // Di chuyển đến gần mob nếu cần
          const distance = bot.entity.position.distanceTo(mob.position)
          if (distance > 6) {
            const movements = new Movements(bot)
            movements.canDig = false // Không đào khi farm
            movements.allowSprinting = true
            movements.allowParkour = true
            bot.pathfinder.setMovements(movements)

            bot.pathfinder.setGoal(new goals.GoalFollow(mob, 2))

            // Đợi di chuyển một chút
            await new Promise(resolve => setTimeout(resolve, 500))
          }

          // Tấn công mob gần nhất với kiểm tra autoBowMode
          const mobDistance = bot.entity.position.distanceTo(mob.position)

          // Bow code removed - only melee attack
          {
            // Tấn công cận chiến - ULTRA SPAM cho mob ≤7 blocks
            equipBestWeapon()
            bot.setControlState('sprint', true)

            if (mob && mob.isValid && mobDistance <= 7) {
              // ULTRA SPAM ATTACK - 15 lần liên tiếp trong farm mode
              for (let ultraSpam = 0; ultraSpam < 15; ultraSpam++) {
                meleeAttack(mob, mobDistance)
              }
              console.log(`🔥 FARM ULTRA SPAM x15 - ${mob.name}`)
            }
          }

          // Thu thập item sau khi giết
          setTimeout(() => {
            const entities = Object.values(bot.entities)
            for (const entity of entities) {
              if (entity.name === 'item' && entity.position && 
                  bot.entity.position.distanceTo(entity.position) < 8) {
                bot.collectBlock.collect(entity).catch(() => {})
              }
            }
          }, 1000)

        } else {
          // Không có mob gần, di chuyển ngẫu nhiên để tìm
          if (Math.random() < 0.3) { // 30% cơ hội di chuyển
            const randomX = Math.floor(Math.random() * 21) - 10
            const randomZ = Math.floor(Math.random() * 21) - 10
            const currentPos = bot.entity.position
            const goal = new goals.GoalXZ(currentPos.x + randomX, currentPos.z + randomZ)
            bot.pathfinder.setGoal(goal)
          }
        }
      } catch (error) {
        console.log('Lỗi auto farm:', error)
        bot.pathfinder.setGoal(null)
        bot.pvp.stop()
      }
    }, 500) // Tăng tốc độ farm
  }




  // Heartbeat để duy trì connection - gửi tin nhắn im lặng mỗi 5 phút
  setInterval(() => {
    if (bot && bot._client && bot._client.state === 'play') {
      try {
        // Gửi packet nhỏ để duy trì connection mà không spam chat
        bot.setControlState('sneak', true)
        setTimeout(() => {
          if (bot && bot._client && bot._client.state === 'play') {
            bot.setControlState('sneak', false)
          }
        }, 100)
      } catch (error) {
        console.log('⚠️ Heartbeat error:', error.message || error)
        // Stop all activities if heartbeat fails
        if (error.code === 'EPIPE') {
          stopAll()
        }
      }
    }
  }, 300000) // 5 phút

  // Helper function để kiểm tra kết nối trước khi thực hiện hành động
  function isConnected(): boolean {
    return bot && bot._client && bot._client.state === 'play'
  }

  // Error handling
  bot.on('error', (err: any) => {
    console.log('🛑 Bot gặp lỗi:', err.message || err)

    // Mining error handling removed

    // Phân loại lỗi để xử lý phù hợp
    const criticalErrors = ['ENOTFOUND', 'Invalid username', 'EAUTH']
    const networkErrors = ['ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EPIPE', 'socketClosed']

    if (criticalErrors.some(errType => err.message?.includes(errType))) {
      console.log('❌ Lỗi nghiêm trọng, dừng auto-reconnect')
      reconnectAttempts = MAX_RECONNECT_ATTEMPTS // Force stop reconnection
      return
    }

    if (networkErrors.some(errType => err.message?.includes(errType))) {
      console.log('⚠️ Lỗi network/EPIPE, kết nối sẽ được xử lý bởi end event')
      // Stop all activities to prevent further EPIPE errors
      stopAll()
      return
    }

    console.log('⚠️ Lỗi khác, tiếp tục hoạt động...')
  })

  bot.on('end', (reason: string) => {
    console.log('💔 Bot đã ngắt kết nối:', reason)

    // Clear all activities when disconnected
    autoFarmActive = false
    autoChestHuntActive = false
    isEating = false
    stopAll()

    // Cải thiện logic reconnect - tăng delay và thêm điều kiện
    const shouldReconnect = (
      reason === 'socketClosed' || 
      reason === 'disconnect.timeout' || 
      reason === 'disconnect.quitting' ||
      reason === 'ECONNRESET' ||
      !reason || reason === ''
    ) && reconnectAttempts < MAX_RECONNECT_ATTEMPTS

    if (shouldReconnect) {
      reconnectAttempts++
      // Tăng delay base lên 60s và max lên 5 phút để giảm spam reconnect
      const delay = Math.min(60000 * reconnectAttempts, 300000) 
      console.log(`⏳ Server có thể đang không ổn định. Chờ ${delay/1000} giây trước khi reconnect... (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`)

      setTimeout(async () => {
        console.log('🔄 Kiểm tra server và thử kết nối lại...')

        // Kiểm tra server trước khi reconnect
        const serverOnline = await testServerConnection()
        if (!serverOnline) {
          console.log('❌ Server vẫn offline, sẽ thử lại sau...')
          // Reset để thử lại
          setTimeout(() => createBot(), 30000)
          return
        }

        createBot()
      }, delay)
    } else {
      console.log('❌ Dừng auto-reconnect')
      console.log(`💡 Lý do: ${reason} | Số lần thử: ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`)

      // Reset reconnect counter sau 10 phút để có thể thử lại sau
      setTimeout(() => {
        reconnectAttempts = 0
        console.log('🔄 Reset reconnect counter, có thể thử manual restart')
      }, 600000)
    }
  })
}

// Khởi tạo bot
createBot()